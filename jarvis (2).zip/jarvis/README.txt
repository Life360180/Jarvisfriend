J.A.R.V.I.S. — a voice assistant with its own control room
===========================================================

Say "Jarvis" and then a command. He talks back, opens websites, launches
programs on your computer, runs your own custom commands, and shows you a
live 3D map of his "brain" while he works.

QUICK START (2 minutes)
  1. Unzip this folder.
  2. Start the local core:
       Windows:  double-click  start-windows.bat
       Mac:      double-click  start.command   (first time: right-click > Open)
       Linux:    run  ./start.command
     It needs Python 3, which most Macs and Linux machines have. Windows users
     can install it free from python.org (tick "Add Python to PATH").
  3. Your browser opens Jarvis. Use Chrome or Edge. Click "Initialize" and
     allow the microphone.
  4. Say:  "Jarvis, open YouTube"

THE AI KEY (built in, kept private)
  I can't supply a key for you: keys belong to an account, and they cost money
  to use. Get one at https://console.anthropic.com, then:
    1. Open  secrets.txt  in any text editor.
    2. Paste the key after  ANTHROPIC_API_KEY=
    3. Save, and restart Jarvis.
  From then on it is "built in": nothing to type in the page, ever. The key
  lives only in secrets.txt, is used by the local core, and is never sent to
  the web page or served to the browser. Anything Jarvis doesn't have a skill
  for goes to the AI, and the AI can open sites, add notes and tasks, start
  timers, switch pages and launch your programs for you.
  Please don't put secrets.txt inside a zip you share, or on a public server.
  Set a spending limit on your account.

THE PAGES (the microphone keeps running as you switch)
  Home       The orb, conversation, weather, timers, tasks and device panel.
  Brain      A 3D map of Jarvis's subsystems: hearing, speech, reasoning,
             skills, memory, the web and reflexes. Drag to turn it, scroll to
             zoom, click a region. It lights up as he works, with a live
             thought stream. Click the example phrases to try them.
             (It is a visualisation of Jarvis, not a scan of the AI model.)
  Commands   Make your own commands. See below.
  Computer   The local core: launch programs, quick sites, action log.
  Say "show me your brain", "go home", "open the commands page".

CUSTOM COMMANDS
  Commands page > New command. Give it phrases to listen for and a list of
  steps. Steps can: say something, open a site, search, start a timer, save a
  note, add a task, read the weather, launch a program, switch page, change
  colours, run a terminal command, wait, or ask the AI.
  Use {input} to capture spoken words:
      phrase  "research {input}"   step  search wikipedia for {input}
  Other placeholders in any text:  {time}  {date}  {name}
  Five examples are included (work mode, focus mode, morning briefing, movie
  night, research). "Templates" adds more. "Draft with AI" writes a command
  from a description. Export/Import shares them as a JSON file.
  Your commands are checked before the built-in ones, so you can override
  anything.

YOUR COMPUTER
  With the local core running, Jarvis can:
    - open links in your default browser (no pop-up blocker in the way)
    - launch programs:  "launch calculator", "open notepad"
  Only programs on the list can be launched. Windows, Mac and Linux each get a
  small built-in list. Add your own in apps.json, for example:
      { "spotify": { "label": "Spotify", "cmd": ["spotify"] },
        "vscode": "code" }
  then restart Jarvis and say "launch vscode". "What programs can you launch?"
  lists them. The core listens only on your own machine (127.0.0.1) and refuses
  requests from other websites.
  "Workstation" is a separate sandboxed terminal and file system inside the
  page. It cannot touch your real files.

THINGS TO SAY
  "Open GitHub"                       "Search for pizza near me"
  "What's the weather in Tokyo?"      "Set a timer for 10 minutes"
  "Take a note: call the plumber"     "Add milk to my to-do list"
  "What's 15 percent of 240?"         "System status"
  "Play lo-fi beats on YouTube"       "Tell me a joke"    "Suit up"
  "Show me your brain"                "List my commands"
  You can also type in the bar at the bottom. After Jarvis answers he keeps
  listening for about 7 seconds, so you can skip the wake word.

WITHOUT PYTHON
  Jarvis still works if you host the folder on any static site, or open it
  from any local web server. You lose the local-core abilities (private key,
  launching programs, opening links past the pop-up blocker). Paste a key in
  Settings instead, and allow pop-ups for the page.

FILES
  server.py      The local core.            secrets.txt   Your API key.
  apps.json      Programs you allow.        index.html, style.css
  app.js         Voice, skills, AI.         brain.js      The 3D brain.
  commands.js    Custom commands.           pages.js      Pages and launcher.

PRIVACY
  Chrome and Edge send microphone audio to their own speech service to turn
  it into text, so voice needs internet. Jarvis doesn't record audio. Notes,
  tasks, custom commands and files stay in this browser. Weather uses
  open-meteo.com. AI requests go to api.anthropic.com and are billed to you.

TROUBLESHOOTING
  "AI key: not set"          Check secrets.txt has  ANTHROPIC_API_KEY=sk-ant-...
                             on one line, then restart Jarvis.
  Not hearing "Jarvis"       Try another wake word in Settings; check the mic.
  "Microphone blocked"       Click the lock icon in the address bar > allow mic.
  Launch says not found      Add the program to apps.json and restart.
  Port in use                Jarvis tries ports 8080 to 8089 automatically.
  Firefox                    No speech recognition; typing works.
