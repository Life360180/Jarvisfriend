#!/usr/bin/env python3
"""
J.A.R.V.I.S. local core.

Serves the web interface on http://localhost:8080 and gives it three extra abilities:
  1. Keeps your Anthropic API key on the server (secrets.txt) so it never reaches the web page.
  2. Opens links in your normal browser, which avoids pop-up blockers.
  3. Launches programs on this computer, but only the ones listed in apps.json / the built-in list.

It only listens on 127.0.0.1, so nothing else on your network can reach it.
Python 3.7+, standard library only.
"""
import json, os, sys, secrets, platform, shutil, subprocess, threading, webbrowser
import urllib.request, urllib.error, shlex, hmac
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlparse

ROOT = os.path.dirname(os.path.abspath(__file__))
TOKEN = secrets.token_urlsafe(24)
PORTS = list(range(8080, 8090))
LOCAL_HOSTS = ("localhost", "127.0.0.1", "::1", "[::1]")
STATIC_OK = {".html", ".css", ".js", ".svg", ".png", ".ico", ".txt", ".woff2", ".map"}
STATIC_DENY = {"secrets.txt"}
DEFAULT_MODEL = "claude-sonnet-5"


# ---------------------------------------------------------------- settings
def read_secrets():
    """Reads KEY=value lines from secrets.txt. Environment variables win."""
    out = {}
    try:
        with open(os.path.join(ROOT, "secrets.txt"), encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                out[k.strip()] = v.strip().strip('"').strip("'")
    except OSError:
        pass
    for k in ("ANTHROPIC_API_KEY", "MODEL"):
        if os.environ.get(k):
            out[k] = os.environ[k]
    return out


def api_key():
    k = read_secrets().get("ANTHROPIC_API_KEY", "")
    return k if k.startswith("sk-") else ""


def model_name():
    return read_secrets().get("MODEL") or DEFAULT_MODEL


# ---------------------------------------------------------------- launchable apps
def builtin_apps():
    apps = {}
    system = platform.system()
    if system == "Windows":
        apps = {
            "notepad": ("Notepad", ["notepad.exe"]),
            "calculator": ("Calculator", ["calc.exe"]),
            "paint": ("Paint", ["mspaint.exe"]),
            "file explorer": ("File Explorer", ["explorer.exe"]),
            "task manager": ("Task Manager", ["taskmgr.exe"]),
            "snipping tool": ("Snipping Tool", ["snippingtool.exe"]),
            "windows settings": ("Windows Settings", ["explorer.exe", "ms-settings:"]),
        }
    elif system == "Darwin":
        for key, label, app in [
            ("calculator", "Calculator", "Calculator"), ("textedit", "TextEdit", "TextEdit"),
            ("finder", "Finder", "Finder"), ("terminal", "Terminal", "Terminal"),
            ("notes", "Notes", "Notes"), ("music", "Music", "Music"),
            ("safari", "Safari", "Safari"), ("system settings", "System Settings", "System Settings"),
            ("activity monitor", "Activity Monitor", "Activity Monitor"),
        ]:
            apps[key] = (label, ["open", "-a", app])
    else:
        for key, label, exe in [
            ("calculator", "Calculator", "gnome-calculator"), ("text editor", "Text Editor", "gnome-text-editor"),
            ("gedit", "Gedit", "gedit"), ("files", "Files", "nautilus"), ("terminal", "Terminal", "gnome-terminal"),
            ("system monitor", "System Monitor", "gnome-system-monitor"),
        ]:
            if shutil.which(exe):
                apps[key] = (label, [exe])
    return apps


def load_apps():
    apps = dict(builtin_apps())
    try:
        with open(os.path.join(ROOT, "apps.json"), encoding="utf-8") as f:
            custom = json.load(f)
        for name, spec in custom.items():
            if name.startswith("_"):
                continue
            if isinstance(spec, str):
                apps[name.lower()] = (name.title(), shlex.split(spec, posix=os.name != "nt"))
            elif isinstance(spec, dict) and spec.get("cmd"):
                cmd = spec["cmd"]
                cmd = shlex.split(cmd, posix=os.name != "nt") if isinstance(cmd, str) else list(cmd)
                apps[name.lower()] = (spec.get("label", name.title()), cmd)
    except (OSError, ValueError, AttributeError):
        pass
    return apps


def launch(name):
    apps = load_apps()
    entry = apps.get(name.lower().strip())
    if not entry:
        return False, "I don't have an app called that. Add it to apps.json."
    label, cmd = entry
    kw = {"stdin": subprocess.DEVNULL, "stdout": subprocess.DEVNULL, "stderr": subprocess.DEVNULL}
    if os.name == "nt":
        kw["creationflags"] = 0x00000008 | 0x00000200  # DETACHED_PROCESS | NEW_PROCESS_GROUP
    else:
        kw["start_new_session"] = True
    try:
        subprocess.Popen(cmd, **kw)
        return True, label
    except (OSError, ValueError) as e:
        return False, "Couldn't start %s: %s" % (label, e)


# ---------------------------------------------------------------- HTTP handler
class Handler(SimpleHTTPRequestHandler):
    server_version = "JarvisCore/2.0"

    def __init__(self, *a, **kw):
        super().__init__(*a, directory=ROOT, **kw)

    def log_message(self, fmt, *args):
        try:
            msg = fmt % args
        except (TypeError, ValueError):
            return
        if "/api/" in msg:
            sys.stderr.write("  %s\n" % msg)

    # --- security helpers
    def _host_ok(self):
        host = (self.headers.get("Host") or "").lower()
        host = host.rsplit(":", 1)[0] if not host.startswith("[") else host.split("]")[0] + "]"
        return host in LOCAL_HOSTS

    def _origin_ok(self):
        origin = self.headers.get("Origin")
        if not origin:
            return True
        return (urlparse(origin).hostname or "") in ("localhost", "127.0.0.1", "::1")

    def _authed(self):
        tok = self.headers.get("X-Jarvis-Token", "")
        return self._host_ok() and self._origin_ok() and hmac.compare_digest(tok, TOKEN)

    def _json(self, code, obj):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _body(self):
        n = int(self.headers.get("Content-Length") or 0)
        if n > 1_000_000:
            raise ValueError("too large")
        return json.loads(self.rfile.read(n) or b"{}")

    def end_headers(self):
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        if not self.path.startswith("/api/"):
            self.send_header("Cache-Control", "no-cache")
        super().end_headers()

    # --- routes
    def do_GET(self):
        path = urlparse(self.path).path
        if not self._host_ok():
            return self._json(403, {"error": "bad host"})
        if path == "/api/hello":
            apps = {k: v[0] for k, v in load_apps().items()}
            return self._json(200, {
                "token": TOKEN, "hasKey": bool(api_key()), "model": model_name(),
                "apps": apps, "os": platform.system(), "python": platform.python_version(),
            })
        if path == "/api/sysinfo":
            if not self._authed():
                return self._json(403, {"error": "forbidden"})
            try:
                du = shutil.disk_usage(os.path.expanduser("~"))
                disk = {"total": du.total, "free": du.free}
            except OSError:
                disk = None
            return self._json(200, {
                "hostname": platform.node(), "platform": platform.platform(),
                "cpus": os.cpu_count(), "disk": disk, "python": platform.python_version(),
                "home": os.path.expanduser("~"),
            })
        if path.startswith("/api/"):
            return self._json(404, {"error": "unknown endpoint"})
        # static files: allowlisted types only, never the secrets file
        name = os.path.basename(path.rstrip("/")) or "index.html"
        ext = os.path.splitext(name)[1].lower()
        if path in ("", "/"):
            self.path = "/index.html"
        elif name.lower() in STATIC_DENY or name.startswith(".") or ext not in STATIC_OK:
            return self.send_error(404)
        return super().do_GET()

    def do_POST(self):
        path = urlparse(self.path).path
        if not self._authed():
            return self._json(403, {"error": "forbidden"})
        try:
            data = self._body()
        except (ValueError, json.JSONDecodeError):
            return self._json(400, {"error": "bad request"})

        if path == "/api/open-url":
            url = str(data.get("url", ""))
            if not url.lower().startswith(("http://", "https://")):
                return self._json(400, {"error": "only http(s) links"})
            webbrowser.open(url)
            return self._json(200, {"ok": True})

        if path == "/api/launch":
            ok, msg = launch(str(data.get("app", "")))
            return self._json(200 if ok else 404, {"ok": ok, "message": msg})

        if path == "/api/chat":
            key = api_key()
            if not key:
                return self._json(400, {"error": "no_key"})
            payload = {
                "model": data.get("model") or model_name(),
                "max_tokens": min(int(data.get("max_tokens", 400)), 2000),
                "system": data.get("system", ""),
                "messages": data.get("messages", []),
            }
            req = urllib.request.Request(
                "https://api.anthropic.com/v1/messages", data=json.dumps(payload).encode(),
                headers={"content-type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01"},
            )
            try:
                with urllib.request.urlopen(req, timeout=60) as r:
                    return self._json(200, json.loads(r.read()))
            except urllib.error.HTTPError as e:
                return self._json(e.code, {"error": "upstream", "status": e.code})
            except (urllib.error.URLError, TimeoutError, OSError):
                return self._json(502, {"error": "unreachable"})

        return self._json(404, {"error": "unknown endpoint"})


def main():
    server = None
    for port in PORTS:
        try:
            server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
            break
        except OSError:
            continue
    if not server:
        print("Couldn't find a free port between 8080 and 8089. Close other programs and try again.")
        sys.exit(1)
    url = "http://localhost:%d" % server.server_address[1]
    print()
    print("  J.A.R.V.I.S. local core is running at " + url)
    print("  AI key:  " + ("found in secrets.txt" if api_key() else "not set (paste one into secrets.txt to enable the AI brain)"))
    print("  Leave this window open. Press Ctrl+C to shut Jarvis down.")
    print()
    if "--no-browser" not in sys.argv:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n  Shutting down. Goodbye.")


if __name__ == "__main__":
    main()
