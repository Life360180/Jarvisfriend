'use strict';

/* =====================================================================
   Pages, the local core connection, and the Computer page.

   Everything stays in one document so the microphone and the wake word
   keep running while you move between Home, Brain, Commands and Computer.
   ===================================================================== */
(() => {
  const PAGES = ['home', 'brain', 'commands', 'computer'];

  /* ---------- page router ---------- */
  function showPage(name) {
    name = String(name || '').toLowerCase().trim();
    if (!PAGES.includes(name)) return false;
    document.body.dataset.page = name;
    for (const p of PAGES) { const sec = $('#page-' + p); if (sec) sec.hidden = p !== name; }
    $$('.tab').forEach(b => (b.dataset.page === name ? b.setAttribute('aria-current', 'page') : b.removeAttribute('aria-current')));
    Brain.setVisible(name === 'brain');
    if (name === 'computer') refreshComputer();
    try { history.replaceState(null, '', '#' + name); } catch { /* file:// in some browsers */ }
    const pg = $('#pages'); pg.classList.remove('sweep'); void pg.offsetWidth; pg.classList.add('sweep');
    return true;
  }
  window.showPage = showPage;

  $$('.tab').forEach(b => b.addEventListener('click', () => { tone(1250, .04, 0, 'sine', .03); showPage(b.dataset.page); }));
  window.addEventListener('hashchange', () => { const h = location.hash.slice(1); if (PAGES.includes(h)) showPage(h); });

  Brain.onTry = text => { audio(); handleCommand(text, { typed: true }); };

  /* ---------- action log (Computer page) ---------- */
  const actions = [];
  const clock = ms => new Date(ms).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', second: '2-digit' });
  function renderActions() {
    const ul = $('#cpLog'); if (!ul) return;
    ul.innerHTML = actions.length
      ? actions.map(a => `<li><i></i><span class="tx">${esc(a.text)}</span><time>${clock(a.t)}</time></li>`).join('')
      : '<li class="muted">Nothing yet. Links opened and programs launched will show up here.</li>';
  }
  window.logAction = text => { actions.unshift({ t: Date.now(), text }); if (actions.length > 25) actions.pop(); renderActions(); };

  /* ---------- local core ---------- */
  async function initCore() {
    try {
      const r = await fetch('/api/hello', { cache: 'no-store' });
      if (!r.ok) throw new Error('no core');
      const d = await r.json();
      Object.assign(core, { online: true, hasKey: !!d.hasKey, model: d.model || '', token: d.token || '', apps: d.apps || {}, os: d.os || '' });
    } catch { core.online = false; }

    // add a line to the boot screen
    const ul = $('#bootLines');
    if (ul && ul.lastElementChild) {
      const li = document.createElement('li'), last = ul.lastElementChild;
      li.textContent = core.online ? (core.hasKey ? 'Local core online, AI key loaded' : 'Local core online, no AI key yet') : 'Browser mode (no local core)';
      if (!core.online) li.className = 'warn';
      li.style.animationDelay = last.style.animationDelay;
      last.style.animationDelay = (parseFloat(last.style.animationDelay || '0') + 0.35) + 's';
      ul.insertBefore(li, last);
    }
    updateAiVital();
    if (document.body.dataset.page === 'computer') refreshComputer();
  }

  /* ---------- launching programs ---------- */
  const ALIASES = {
    calc: ['calculator'], calculator: ['calculator'],
    files: ['file explorer', 'finder', 'files'], explorer: ['file explorer'], 'file manager': ['file explorer', 'finder', 'files'],
    'text edit': ['textedit'], editor: ['notepad', 'textedit', 'text editor', 'gedit'],
    taskmgr: ['task manager'], 'task manager': ['task manager', 'activity monitor'], 'system monitor': ['system monitor', 'activity monitor', 'task manager']
  };
  function matchApp(raw) {
    const n = String(raw).toLowerCase().trim().replace(/^(?:the|my|up)\s+/, '').replace(/\s+(?:app|application|program)$/, '');
    const keys = Object.keys(core.apps);
    if (keys.includes(n)) return n;
    for (const a of ALIASES[n] || []) if (keys.includes(a)) return a;
    if (n.length >= 3) return keys.find(k => k.includes(n) || n.includes(k)) || null;
    return null;
  }

  window.launchApp = async name => {
    if (!core.online) return { ok: false, message: `I can only launch programs when the local core is running, ${sir()}. Start me with start.command or start-windows.bat.` };
    const key = matchApp(name);
    if (!key) return { ok: false, message: `I don’t have a program called ${name}. Add it to apps.json and I’ll be able to launch it.` };
    try {
      const r = await corePost('/api/launch', { app: key }), d = await r.json();
      if (d.ok) { window.logAction(`Launched ${d.message}`); Brain.emit('skills', `Launched ${d.message}`, 1); return { ok: true, message: `Launching ${d.message}.` }; }
      return { ok: false, message: d.message || 'That didn’t work.' };
    } catch { return { ok: false, message: 'I couldn’t reach the local core.' }; }
  };

  // Words that already mean something else ("open terminal" is the virtual workstation, not a real terminal).
  const RESERVED = new Set(['terminal', 'files', 'notes', 'settings', 'monitor', 'computer', 'workstation', 'browser', 'console', 'editor', 'file manager']);

  INTENTS.unshift([/^(launch|open|start|run|fire up)\s+(.+?)(\s+(?:on|from|in) (?:my|the) computer)?$/, async m => {
    const explicit = /^(?:launch|fire up)$/.test(m[1]) || !!m[3];
    const name = m[2].replace(/^(?:the|my)\s+/, '');
    if (!core.online) return m[3] ? { say: (await window.launchApp(name)).message } : null;
    if (!explicit && RESERVED.has(name)) return null;
    const key = matchApp(name);
    if (!key) return m[3] ? { say: `I don’t have a program called ${name}. You can add it to apps.json.` } : null;
    return { say: (await window.launchApp(key)).message };
  }]);

  INTENTS.unshift([/^(?:what|which) (?:programs|apps|applications) (?:can you|do you) (?:launch|open|run|start)$|^(?:list|show) (?:the )?(?:launchable|available) (?:programs|apps)$/, () => {
    if (!core.online) return { say: `I can only launch programs when the local core is running, ${sir()}.` };
    const names = Object.values(core.apps);
    return names.length ? { say: `I can launch ${names.join(', ')}.` } : { say: 'No programs are set up yet. Add some to apps.json.' };
  }]);

  /* ---------- voice navigation ---------- */
  const PAGE_SAY = {
    home: 'Back to the main display.', brain: 'Here is my brain. Select any region to see what it does.',
    commands: 'Here are your custom commands.', computer: 'This is the computer page.'
  };
  const goto = name => { showPage(name); return { say: PAGE_SAY[name] }; };
  const NAV = '(?:go to|open|show|switch to|take me to|bring up|go back to|let me see)(?: me)?(?: the| your| my)?';
  INTENTS.unshift([new RegExp(`^${NAV}\\s*(home|dashboard|main(?: display| screen)?|brain|mind|neural map|commands|custom commands)(?: page| tab| screen| view)?$`), m => {
    const w = m[1]; return goto(/^(?:brain|mind|neural)/.test(w) ? 'brain' : /command/.test(w) ? 'commands' : 'home');
  }]);
  INTENTS.unshift([new RegExp(`^${NAV}\\s*(?:computer|systems?|launcher)\\s+(?:page|tab|screen|view)$`), () => goto('computer')]);
  INTENTS.unshift([/^(?:go home|take me home|back to (?:the )?(?:main|home)(?: page| screen)?)$/, () => goto('home')]);

  /* ---------- Computer page ---------- */
  const fmtBytes = n => n >= 1e12 ? (n / 1e12).toFixed(1) + ' TB' : n >= 1e9 ? (n / 1e9).toFixed(0) + ' GB' : Math.round(n / 1e6) + ' MB';
  const QUICK = ['youtube', 'gmail', 'github', 'google maps', 'netflix', 'spotify', 'wikipedia', 'news', 'reddit', 'chatgpt'];

  async function refreshComputer() {
    const mode = $('#cpMode'), info = $('#cpInfo'), help = $('#cpHelp'), apps = $('#cpApps'), note = $('#cpAppsNote');
    mode.innerHTML = core.online
      ? '<b class="ok">Local core connected.</b> I can launch programs, open links in your default browser and keep your AI key private.'
      : '<b class="warn">Browser mode.</b> I’m running as a plain web page, so I can’t launch programs or hide an API key. Start me with start-windows.bat or start.command to connect the local core.';
    help.textContent = core.online
      ? 'Only programs on the list can be launched. Add your own by editing apps.json, then restart Jarvis.'
      : 'A web page can’t touch your computer by design. The local core is a small Python program that runs beside this page and does it on the page’s behalf.';

    let rows = [['Mode', core.online ? 'Local core' : 'Browser only'], ['CPU threads', navigator.hardwareConcurrency || '—']];
    if (core.online) {
      try {
        const r = await fetch('/api/sysinfo', { headers: { 'x-jarvis-token': core.token } });
        if (r.ok) {
          const d = await r.json();
          rows = [['Computer', d.hostname || '—'], ['System', d.platform || '—'], ['CPU threads', d.cpus || '—'],
            ['Free disk space', d.disk ? `${fmtBytes(d.disk.free)} of ${fmtBytes(d.disk.total)}` : '—'],
            ['AI key', core.hasKey ? 'Loaded from secrets.txt' : 'Not set'], ['Launchable programs', Object.keys(core.apps).length]];
        }
      } catch { /* keep basic rows */ }
    }
    info.innerHTML = rows.map(([k, v]) => `<dt>${esc(k)}</dt><dd>${esc(v)}</dd>`).join('');

    const keys = Object.keys(core.apps);
    apps.innerHTML = keys.map(k => `<button type="button" class="tile" data-app="${esc(k)}"><b>${esc(core.apps[k])}</b><span>“launch ${esc(k)}”</span></button>`).join('');
    note.textContent = !core.online ? 'Start the local core to unlock this.' : keys.length ? '' : 'No programs are configured for this system yet. Add some in apps.json.';
    $('#cpSites').innerHTML = QUICK.map(k => `<button type="button" class="tile sm" data-site="${esc(k)}"><b>${esc(prettyName(k))}</b></button>`).join('');
    renderActions();
  }

  $('#page-computer').addEventListener('click', async e => {
    const a = e.target.closest('[data-app]'), s = e.target.closest('[data-site]');
    if (a) { audio(); const r = await window.launchApp(a.dataset.app); log('jarvis', r.message); }
    if (s) { const r = openSiteByName(s.dataset.site); if (r.ok === false) log('jarvis', r.say, r.links); }
  });

  /* ---------- start ---------- */
  const h = location.hash.slice(1);
  showPage(PAGES.includes(h) ? h : 'home');
  updateAiVital();
  initCore();
})();
