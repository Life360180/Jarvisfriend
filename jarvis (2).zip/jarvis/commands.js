'use strict';

/* =====================================================================
   Custom commands.

   A command is:  { id, name, phrases: [..], steps: [{type, value, extra}], enabled, runs }
   Phrases may contain {input}, which captures whatever you say there.
   Steps run in order. Text fields accept {input} {time} {date} {name}.

   app.js calls matchCustom() and runCustom() from its command router.
   ===================================================================== */
(() => {
  const THEMES = ['blue', 'red', 'gold', 'green'];
  const PAGE_OPTS = [['home', 'Home'], ['brain', 'Brain'], ['commands', 'Commands'], ['computer', 'Computer']];

  // Every kind of step the builder offers. `kind:'select'` steps pick from a list instead of typing.
  const STEP_DEFS = {
    say:     { label: 'Say aloud', ph: 'Good morning, {name}.' },
    open:    { label: 'Open a website', ph: 'youtube, or github.com' },
    search:  { label: 'Search the web', ph: '{input}', extra: { kind: 'select', options: () => Object.keys(ENGINES).map(k => [k, prettyName(k)]) } },
    timer:   { label: 'Start a timer', ph: '25 minutes', extra: { kind: 'text', ph: 'Reminder text (optional)' } },
    note:    { label: 'Save a note', ph: '{input}' },
    task:    { label: 'Add a task', ph: '{input}' },
    weather: { label: 'Read the weather', ph: 'City, or leave blank for home', optional: true },
    launch:  { label: 'Launch a program', ph: 'calculator (needs the local core)' },
    page:    { label: 'Go to a page', kind: 'select', options: PAGE_OPTS },
    theme:   { label: 'Change colours', kind: 'select', options: THEMES.map(t => [t, cap(t)]) },
    shell:   { label: 'Run in the virtual terminal', ph: 'echo hello > ~/hello.txt' },
    wait:    { label: 'Wait (seconds)', ph: '3' },
    ask:     { label: 'Ask the AI', ph: 'Give me a one-line quote to start the day' }
  };

  const TEMPLATES = [
    { name: 'Work mode', phrases: ['work mode', 'get me ready for work', 'start my workday'], steps: [
      { type: 'say', value: 'Work mode engaged, {name}. Opening your workspace.' },
      { type: 'open', value: 'gmail' }, { type: 'open', value: 'google calendar' }, { type: 'open', value: 'github' }] },
    { name: 'Focus mode', phrases: ['focus mode', 'help me focus', 'let’s focus'], steps: [
      { type: 'say', value: 'Focus mode. Twenty-five minutes, no distractions.' },
      { type: 'timer', value: '25 minutes', extra: 'Focus session finished. Take a break, {name}.' },
      { type: 'search', value: 'lofi hip hop radio', extra: 'youtube' }] },
    { name: 'Morning briefing', phrases: ['morning briefing', 'brief me', 'start my day'], steps: [
      { type: 'say', value: 'Good morning, {name}. It is {time} on {date}.' },
      { type: 'weather', value: '' }, { type: 'open', value: 'news' }, { type: 'open', value: 'google calendar' }] },
    { name: 'Movie night', phrases: ['movie night', 'let’s watch a movie'], steps: [
      { type: 'say', value: 'Movie night it is. Enjoy the show, {name}.' },
      { type: 'theme', value: 'gold' }, { type: 'open', value: 'netflix' }] },
    { name: 'Research a topic', phrases: ['research {input}', 'dig into {input}'], steps: [
      { type: 'say', value: 'Researching {input}.' },
      { type: 'search', value: '{input}', extra: 'wikipedia' }, { type: 'search', value: '{input}', extra: 'google' }] },
    { name: 'Quick capture', phrases: ['capture {input}', 'stash {input}'], steps: [
      { type: 'note', value: '{input}' }, { type: 'say', value: 'Captured.' }] },
    { name: 'Study session', phrases: ['study time', 'study session'], steps: [
      { type: 'say', value: 'Fifty minutes on the clock. Phone away, {name}.' },
      { type: 'timer', value: '50 minutes', extra: 'Study session over. Stretch your legs.' },
      { type: 'search', value: 'study music', extra: 'youtube' }] },
    { name: 'Goodnight', phrases: ['goodnight jarvis', 'lights out'], steps: [
      { type: 'say', value: 'Goodnight, {name}. Standing by.' }, { type: 'theme', value: 'red' }] }
  ];
  const SEED_NAMES = ['Work mode', 'Focus mode', 'Morning briefing', 'Movie night', 'Research a topic'];

  /* ---------- storage ---------- */
  const uid = () => 'c' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  const fromTemplate = t => ({ id: uid(), name: t.name, phrases: [...t.phrases], steps: t.steps.map(s => ({ extra: '', ...s })), enabled: true, runs: 0 });
  let cmds = store.get('commands', null);
  if (!Array.isArray(cmds)) { cmds = TEMPLATES.filter(t => SEED_NAMES.includes(t.name)).map(fromTemplate); store.set('commands', cmds); }
  const save = () => store.set('commands', cmds);

  function cleanStep(s) {
    const d = s && STEP_DEFS[s.type]; if (!d) return null;
    let value = String(s.value ?? '').slice(0, 300), extra = String(s.extra ?? '').slice(0, 160);
    if (d.kind === 'select') { const ok = d.options.map(o => o[0]); if (!ok.includes(value)) value = ok[0]; }
    else if (!d.optional && !value.trim()) return null;
    if (d.extra?.kind === 'select') { const ok = d.extra.options().map(o => o[0]); if (!ok.includes(extra)) extra = ok[0]; }
    return { type: s.type, value, extra };
  }
  function clean(o) {
    if (!o || typeof o !== 'object') return null;
    const phrases = (Array.isArray(o.phrases) ? o.phrases : []).map(p => String(p).trim().slice(0, 80)).filter(Boolean).slice(0, 10);
    const steps = (Array.isArray(o.steps) ? o.steps : []).map(cleanStep).filter(Boolean).slice(0, 20);
    if (!phrases.length || !steps.length) return null;
    return { id: uid(), name: String(o.name || '').trim().slice(0, 40) || phrases[0], phrases, steps, enabled: o.enabled !== false, runs: Math.max(0, +o.runs || 0) };
  }

  /* ---------- matching ---------- */
  const reCache = new Map();
  function phraseRe(p) {
    let re = reCache.get(p);
    if (!re) {
      const body = escRe(normalize(p)).replace(/\\\{input\\\}/g, '(.+)');
      re = new RegExp('^(?:(?:run|start|activate|launch|initiate|execute|enable)\\s+)?(?:the\\s+|my\\s+)?' + body + '$');
      reCache.set(p, re);
    }
    return re;
  }
  function matchCustom(t) {
    for (const cmd of cmds) {
      if (!cmd.enabled) continue;
      for (const p of cmd.phrases) {
        const m = t.match(phraseRe(p));
        if (m) return { cmd, input: (m[1] || '').trim() };
      }
    }
    return null;
  }

  const fill = (str, input) => String(str || '').replace(/\{(input|time|date|name)\}/gi, (_, k) => ({
    input: input || '',
    time: new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }),
    date: new Date().toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric' }),
    name: sir()
  }[k.toLowerCase()]));

  /* ---------- running ---------- */
  async function runCustom(cmd, input = '', meta = {}, opts = {}) {
    if (meta.show) meta.show();
    if (!opts.dry) { cmd.runs = (cmd.runs || 0) + 1; save(); renderList(); }
    Brain.emit('skills', `Custom command: ${cmd.name}`, 1);

    const links = []; let spoke = false, blocked = false;
    for (let i = 0; i < cmd.steps.length; i++) {
      const step = cmd.steps[i], v = fill(step.value, input);
      try {
        switch (step.type) {
          case 'say': spoke = true; await respond({ say: v }); break;
          case 'open': { const r = openSiteByName(v); if (r.links) links.push(...r.links); if (r.ok === false) blocked = true; break; }
          case 'search': { const r = doSearch(v, step.extra || 'google'); links.push(...r.links); if (r.ok === false) blocked = true; break; }
          case 'timer': { const s = parseDuration(v); if (s) addTimer(s, fill(step.extra, input)); break; }
          case 'note': addNote(v); Brain.emit('memory', 'Saved a note'); break;
          case 'task': addTask(v); Brain.emit('memory', 'Added a task'); break;
          case 'weather': { spoke = true; let say; try { say = await weatherCmd(v); } catch (e) { say = e.message; } await respond({ say }); break; }
          case 'launch': { const r = await launchApp(v); if (!r.ok) { spoke = true; await respond({ say: r.message }); } break; }
          case 'page': showPage(step.value); break;
          case 'theme': setTheme(step.value); break;
          case 'shell': await runInTerminal(v); break;
          case 'wait': await sleep(Math.min(60, Math.max(0, parseFloat(v) || 1)) * 1000); break;
          case 'ask': {
            spoke = true;
            if (!aiReady()) { await respond({ say: `I need an AI key for that step, ${sir()}. See Settings or secrets.txt.` }); break; }
            const out = applyTags(await askClaude(v)); await respond({ say: out.clean || 'Done.', links: out.links }); break;
          }
        }
      } catch (e) {
        console.warn('Custom step failed', step, e);
        spoke = true; await respond({ say: `Step ${i + 1} of ${cmd.name} failed. ${e.message || ''}`.trim() });
      }
    }
    if (!spoke) await respond({ say: `Running ${cmd.name}.` + (blocked ? ' Your browser blocked some pop-ups, so I’ve left links below.' : ''), links });
    else if (links.length) log('jarvis', blocked ? 'Pop-ups were blocked. Use these links:' : 'Opened:', links);
    return { silent: true };
  }

  /* ---------- voice: “list my commands” ---------- */
  INTENTS.unshift([/^(?:list|what are|what'?s|show|read)(?: me)?(?: all)?(?: of)?(?: my| the)?(?: custom)? commands$/, () => {
    const on = cmds.filter(c => c.enabled);
    if (!on.length) return { say: 'You haven’t made any custom commands yet. Open the Commands page to add one.' };
    return {
      say: `You have ${on.length} custom command${on.length > 1 ? 's' : ''}: ${on.map(c => c.name).join(', ')}.`,
      display: on.map(c => `• ${c.name}: “${c.phrases[0]}”`).join('\n')
    };
  }]);

  /* ---------- editor UI ---------- */
  const $list = $('#cmList'), $steps = $('#cmSteps');
  let draft = null;

  const opts = (list, sel) => list.map(([v, l]) => `<option value="${esc(v)}"${v === sel ? ' selected' : ''}>${esc(l)}</option>`).join('');
  const defaultsFor = type => {
    const d = STEP_DEFS[type];
    return { type, value: d.kind === 'select' ? d.options[0][0] : '', extra: d.extra?.kind === 'select' ? d.extra.options()[0][0] : '' };
  };

  function renderList() {
    if (!cmds.length) { $list.innerHTML = '<li class="muted cm-empty">No commands yet. Start with “New command”, or add a template.</li>'; return; }
    $list.innerHTML = cmds.map(c => {
      const extra = c.phrases.length > 1 ? ` <span class="muted">+${c.phrases.length - 1} more</span>` : '';
      return `<li class="cm-item${draft && draft.id === c.id ? ' on' : ''}${c.enabled ? '' : ' off'}" data-id="${c.id}">
        <button type="button" class="cm-main" data-a="edit"><b>${esc(c.name)}</b><span>“${esc(c.phrases[0])}”${extra}</span></button>
        <span class="cm-runs" title="Times run">${c.runs || 0}×</span>
        <button type="button" class="btn sm" data-a="run">Run</button>
        <label class="cm-sw" title="Enable or disable"><input type="checkbox" data-a="toggle" ${c.enabled ? 'checked' : ''} aria-label="Enable ${esc(c.name)}"></label>
      </li>`;
    }).join('');
  }

  function stepHtml(s, i) {
    const d = STEP_DEFS[s.type];
    const type = `<select data-f="type" aria-label="Step ${i + 1} action">${opts(Object.entries(STEP_DEFS).map(([k, v]) => [k, v.label]), s.type)}</select>`;
    const val = d.kind === 'select'
      ? `<select data-f="value" aria-label="Step ${i + 1} setting">${opts(d.options, s.value)}</select>`
      : `<input data-f="value" type="text" value="${esc(s.value)}" placeholder="${esc(d.ph || '')}" spellcheck="false" aria-label="Step ${i + 1} text">`;
    let extra = '';
    if (d.extra) extra = d.extra.kind === 'select'
      ? `<select data-f="extra" aria-label="Step ${i + 1} option">${opts(d.extra.options(), s.extra)}</select>`
      : `<input data-f="extra" type="text" value="${esc(s.extra || '')}" placeholder="${esc(d.extra.ph)}" spellcheck="false" aria-label="Step ${i + 1} extra">`;
    return `<li class="cm-step" data-i="${i}"><span class="cm-n" aria-hidden="true">${i + 1}</span>${type}${val}${extra}
      <span class="cm-sb"><button type="button" data-a="up" aria-label="Move step up">↑</button><button type="button" data-a="down" aria-label="Move step down">↓</button><button type="button" data-a="del" aria-label="Remove step">×</button></span></li>`;
  }
  const renderSteps = () => { $steps.innerHTML = draft.steps.map(stepHtml).join(''); };

  function loadEditor(c) {
    draft = c ? JSON.parse(JSON.stringify(c)) : { id: null, name: '', phrases: [], steps: [defaultsFor('say')] };
    $('#cmTitle').textContent = draft.id ? 'Edit command' : 'New command';
    $('#cmName').value = draft.name;
    $('#cmPhrases').value = draft.phrases.join('\n');
    $('#cmDelete').hidden = !draft.id;
    $('#cmMsg').textContent = ''; $('#cmAiMsg').textContent = '';
    renderSteps(); renderList();
  }

  function readEditor() {
    const o = {
      name: $('#cmName').value, phrases: $('#cmPhrases').value.split('\n'),
      steps: draft.steps
    };
    const c = clean(o);
    if (!c) return null;
    if (draft.id) { const old = cmds.find(x => x.id === draft.id); c.id = draft.id; c.runs = old?.runs || 0; c.enabled = old ? old.enabled : true; }
    return c;
  }

  $steps.addEventListener('input', e => {
    const li = e.target.closest('.cm-step'); if (!li || !e.target.dataset.f) return;
    const s = draft.steps[+li.dataset.i];
    if (e.target.dataset.f === 'type') { draft.steps[+li.dataset.i] = defaultsFor(e.target.value); renderSteps(); }
    else s[e.target.dataset.f] = e.target.value;
  });
  $steps.addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return;
    const i = +b.closest('.cm-step').dataset.i, a = b.dataset.a, st = draft.steps;
    if (a === 'del') st.splice(i, 1);
    if (a === 'up' && i > 0) [st[i - 1], st[i]] = [st[i], st[i - 1]];
    if (a === 'down' && i < st.length - 1) [st[i + 1], st[i]] = [st[i], st[i + 1]];
    if (!st.length) st.push(defaultsFor('say'));
    renderSteps();
  });
  $('#cmAddStep').addEventListener('click', () => { if (draft.steps.length < 20) { draft.steps.push(defaultsFor('say')); renderSteps(); $steps.lastElementChild?.querySelector('input,select')?.focus(); } });
  $('#cmNew').addEventListener('click', () => { loadEditor(null); $('#cmName').focus(); });

  $('#cmForm').addEventListener('submit', e => {
    e.preventDefault();
    const c = readEditor(), msg = $('#cmMsg');
    if (!c) { msg.textContent = 'Give it at least one phrase to listen for and one step with something in it.'; return; }
    const i = cmds.findIndex(x => x.id === c.id);
    if (i >= 0) cmds[i] = c; else cmds.push(c);
    reCache.clear(); save(); loadEditor(c);
    $('#cmMsg').textContent = `Saved. Try saying “${c.phrases[0].replace('{input}', 'something')}”.`;
    Brain.emit('memory', `Saved command: ${c.name}`, 0.7);
  });
  $('#cmTest').addEventListener('click', () => {
    const c = readEditor();
    if (!c) { $('#cmMsg').textContent = 'Add a phrase and at least one step to test it.'; return; }
    audio(); runCustom(c, 'testing', {}, { dry: true });
  });
  $('#cmDelete').addEventListener('click', () => {
    if (!draft?.id || !confirm(`Delete “${draft.name || 'this command'}”?`)) return;
    cmds = cmds.filter(c => c.id !== draft.id); reCache.clear(); save(); loadEditor(null);
  });

  $list.addEventListener('click', e => {
    const li = e.target.closest('.cm-item'); if (!li) return;
    const c = cmds.find(x => x.id === li.dataset.id); if (!c) return;
    const a = e.target.closest('[data-a]')?.dataset.a;
    if (a === 'run') { audio(); runCustom(c, 'testing'); }
    else if (a === 'edit') loadEditor(c);
  });
  $list.addEventListener('change', e => {
    const li = e.target.closest('.cm-item'); const c = li && cmds.find(x => x.id === li.dataset.id);
    if (c && e.target.dataset.a === 'toggle') { c.enabled = e.target.checked; save(); renderList(); }
  });

  // templates
  const $tpl = $('#cmTplList');
  $('#cmTpl').addEventListener('click', ev => {
    $tpl.hidden = !$tpl.hidden; ev.currentTarget.setAttribute('aria-expanded', String(!$tpl.hidden));
    $tpl.innerHTML = TEMPLATES.map((t, i) => `<li><span><b>${esc(t.name)}</b><small>“${esc(t.phrases[0])}”</small></span><button type="button" class="btn sm" data-i="${i}">Add</button></li>`).join('');
  });
  $tpl.addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return;
    const c = fromTemplate(TEMPLATES[+b.dataset.i]); c.name += cmds.some(x => x.name === c.name) ? ' (copy)' : '';
    cmds.push(c); reCache.clear(); save(); loadEditor(c);
  });

  // export / import
  $('#cmExport').addEventListener('click', () => {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([JSON.stringify(cmds, null, 2)], { type: 'application/json' }));
    a.download = 'jarvis-commands.json'; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  });
  $('#cmImport').addEventListener('click', () => $('#cmFile').click());
  $('#cmFile').addEventListener('change', async e => {
    const f = e.target.files[0]; e.target.value = ''; if (!f) return;
    try {
      const data = JSON.parse(await f.text());
      const added = (Array.isArray(data) ? data : [data]).map(clean).filter(Boolean);
      if (!added.length) throw new Error('none');
      cmds.push(...added); reCache.clear(); save(); loadEditor(added[0]);
      $('#cmMsg').textContent = `Imported ${added.length} command${added.length > 1 ? 's' : ''}.`;
    } catch { $('#cmMsg').textContent = 'That file didn’t contain any commands Jarvis could read.'; }
  });

  // draft with AI
  $('#cmAiBtn').addEventListener('click', async () => {
    const msg = $('#cmAiMsg'), text = $('#cmAiText').value.trim();
    if (!text) { msg.textContent = 'Describe what the command should do first.'; return; }
    if (!aiReady()) { msg.textContent = 'This needs an AI key. Paste one into secrets.txt (recommended) or Settings.'; return; }
    msg.textContent = 'Drafting…'; $('#cmAiBtn').disabled = true;
    const system = `You design voice commands for a browser assistant. Reply with ONLY one JSON object, no prose, no code fences:
{"name":"short name","phrases":["what the user says","another way to say it"],"steps":[{"type":"...","value":"...","extra":"..."}]}
Step types and their fields:
say: value = words to speak
open: value = website name or address
search: value = search terms, extra = one of ${Object.keys(ENGINES).join(', ')}
timer: value = duration like "25 minutes", extra = reminder text
note: value = note text
task: value = task text
weather: value = city or empty
launch: value = program name on the user's computer
page: value = one of home, brain, commands, computer
theme: value = one of ${THEMES.join(', ')}
shell: value = command for a sandbox terminal
wait: value = seconds
ask: value = a prompt for the AI whose answer is spoken
Use {input} in phrases and step values when the command takes a spoken argument. Use {name} for how to address the user. Keep phrases short, lowercase and natural to say aloud. Use 1 to 6 steps.`;
    try {
      const out = await callAI(system, [{ role: 'user', content: text }], 700);
      const json = JSON.parse(out.slice(out.indexOf('{'), out.lastIndexOf('}') + 1));
      const c = clean(json);
      if (!c) throw new Error('empty');
      c.id = draft?.id || null; loadEditor(c); draft.id = c.id;
      $('#cmDelete').hidden = !draft.id;
      $('#cmAiMsg').textContent = 'Drafted. Check the steps, then save.';
    } catch (e) {
      $('#cmAiMsg').textContent = e && e.user ? e.message : 'The AI didn’t return something I could use. Try rewording it.';
    } finally { $('#cmAiBtn').disabled = false; }
  });

  window.matchCustom = matchCustom;
  window.runCustom = runCustom;
  window.customCommandCount = () => cmds.length;
  loadEditor(null);
})();
