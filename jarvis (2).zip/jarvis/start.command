#!/bin/bash
# Double-click on a Mac, or run ./start.command on Linux.
cd "$(dirname "$0")"
if command -v python3 >/dev/null 2>&1; then PY=python3
elif command -v python >/dev/null 2>&1; then PY=python
else
  echo "Python was not found. Install it from https://www.python.org/downloads/"
  read -p "Press Enter to close."
  exit 1
fi
$PY server.py
