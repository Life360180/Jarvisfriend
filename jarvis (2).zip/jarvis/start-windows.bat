@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 goto usepy
where python >nul 2>nul
if %errorlevel%==0 goto usepython
echo.
echo Python was not found. Install it free from https://www.python.org/downloads/
echo (tick "Add Python to PATH"), then double-click this file again.
pause
exit /b
:usepy
py -3 server.py
pause
exit /b
:usepython
python server.py
pause
exit /b
