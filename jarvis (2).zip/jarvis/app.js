'use strict';

/* =====================================================================
   J.A.R.V.I.S. — a voice assistant that lives in your browser.

   Sections
     1. Helpers & settings
     2. Sites & search engines (edit SITES to add your own shortcuts)
     3. Audio, speech output, speech input (wake word)
     4. Panels: log, timers, tasks, weather, device
     5. Virtual workstation: file system, shell, windows
     6. Command router (what Jarvis understands)
     7. Optional AI brain (Anthropic API)
     8. Start-up
   ===================================================================== */


/* ---------------------------------------------------------------------
   1. Helpers & settings
   --------------------------------------------------------------------- */
const $  = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const escRe = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const sleep = ms => new Promise(r => setTimeout(r, ms));
const pick = a => a[Math.floor(Math.random() * a.length)];
const cap = s => s.charAt(0).toUpperCase() + s.slice(1);
const titleCase = s => s.replace(/\b\w/g, c => c.toUpperCase());

const store = {
  get(k, d) { try { const v = localStorage.getItem('jarvis.' + k); return v == null ? d : JSON.parse(v); } catch { return d; } },
  set(k, v) { try { localStorage.setItem('jarvis.' + k, JSON.stringify(v)); } catch { /* storage unavailable */ } }
};

const DEFAULTS = {
  wake: 'jarvis',
  address: 'sir',
  units: 'F',
  city: '',
  coords: null,
  voice: '',
  rate: 1,
  pitch: 0.9,
  ackVoice: true,
  orbMic: !/Android|iPhone|iPad/i.test(navigator.userAgent),
  apiKey: '',
  model: 'claude-sonnet-5',
  coreOpen: true
};
let settings = Object.assign({}, DEFAULTS, store.get('settings', {}));
const saveSettings = () => store.set('settings', settings);
const sir = () => settings.address || 'sir';

const sessionStart = Date.now();

// The local core (server.py) is optional. When it is running it keeps the AI key private,
// opens links in your normal browser and can launch programs. pages.js fills this in.
const core = { online: false, hasKey: false, model: '', token: '', apps: {}, os: '' };
const corePost = (path, body) => fetch(path, { method: 'POST', headers: { 'content-type': 'application/json', 'x-jarvis-token': core.token }, body: JSON.stringify(body) });
const aiReady = () => core.hasKey || !!settings.apiKey;
const SR = window.SpeechRecognition || window.webkitSpeechRecognition;

const el = {
  log: $('#log'), status: $('#status'), heard: $('#heard'), orb: $('#orb'),
  clock: $('#clock'), date: $('#date'), micBtn: $('#btnMic'),
  cmdForm: $('#cmdForm'), cmdInput: $('#cmdInput')
};


/* ---------------------------------------------------------------------
   2. Sites & search engines
   --------------------------------------------------------------------- */
const SITES = {
  'youtube': 'https://www.youtube.com', 'google': 'https://www.google.com', 'gmail': 'https://mail.google.com',
  'google drive': 'https://drive.google.com', 'drive': 'https://drive.google.com',
  'google docs': 'https://docs.google.com', 'docs': 'https://docs.google.com',
  'google sheets': 'https://sheets.google.com', 'sheets': 'https://sheets.google.com',
  'google slides': 'https://slides.google.com', 'google calendar': 'https://calendar.google.com',
  'calendar': 'https://calendar.google.com', 'google maps': 'https://maps.google.com', 'maps': 'https://maps.google.com',
  'google photos': 'https://photos.google.com', 'photos': 'https://photos.google.com',
  'google translate': 'https://translate.google.com', 'translate': 'https://translate.google.com',
  'news': 'https://news.google.com', 'google news': 'https://news.google.com',
  'github': 'https://github.com', 'gitlab': 'https://gitlab.com', 'stack overflow': 'https://stackoverflow.com',
  'hacker news': 'https://news.ycombinator.com', 'reddit': 'https://www.reddit.com',
  'twitter': 'https://x.com', 'x': 'https://x.com', 'facebook': 'https://www.facebook.com',
  'instagram': 'https://www.instagram.com', 'linkedin': 'https://www.linkedin.com', 'tiktok': 'https://www.tiktok.com',
  'pinterest': 'https://www.pinterest.com', 'snapchat': 'https://web.snapchat.com',
  'netflix': 'https://www.netflix.com', 'hulu': 'https://www.hulu.com', 'disney plus': 'https://www.disneyplus.com',
  'disney+': 'https://www.disneyplus.com', 'prime video': 'https://www.primevideo.com', 'max': 'https://www.max.com',
  'twitch': 'https://www.twitch.tv', 'spotify': 'https://open.spotify.com', 'apple music': 'https://music.apple.com',
  'soundcloud': 'https://soundcloud.com', 'discord': 'https://discord.com/app', 'whatsapp': 'https://web.whatsapp.com',
  'telegram': 'https://web.telegram.org', 'slack': 'https://app.slack.com', 'zoom': 'https://zoom.us',
  'outlook': 'https://outlook.live.com', 'onedrive': 'https://onedrive.live.com', 'notion': 'https://www.notion.so',
  'trello': 'https://trello.com', 'figma': 'https://www.figma.com', 'canva': 'https://www.canva.com',
  'amazon': 'https://www.amazon.com', 'ebay': 'https://www.ebay.com', 'etsy': 'https://www.etsy.com',
  'walmart': 'https://www.walmart.com', 'target': 'https://www.target.com', 'best buy': 'https://www.bestbuy.com',
  'paypal': 'https://www.paypal.com', 'wikipedia': 'https://www.wikipedia.org', 'imdb': 'https://www.imdb.com',
  'rotten tomatoes': 'https://www.rottentomatoes.com', 'yelp': 'https://www.yelp.com', 'weather channel': 'https://weather.com',
  'chatgpt': 'https://chatgpt.com', 'claude': 'https://claude.ai', 'gemini': 'https://gemini.google.com',
  'perplexity': 'https://www.perplexity.ai', 'nasa': 'https://www.nasa.gov', 'bing': 'https://www.bing.com',
  'duckduckgo': 'https://duckduckgo.com'
};

const ENGINES = {
  google: 'https://www.google.com/search?q=',
  youtube: 'https://www.youtube.com/results?search_query=',
  wikipedia: 'https://en.wikipedia.org/w/index.php?search=',
  amazon: 'https://www.amazon.com/s?k=',
  maps: 'https://www.google.com/maps/search/',
  reddit: 'https://www.reddit.com/search/?q=',
  github: 'https://github.com/search?q=',
  ebay: 'https://www.ebay.com/sch/i.html?_nkw=',
  twitter: 'https://x.com/search?q=',
  spotify: 'https://open.spotify.com/search/',
  imdb: 'https://www.imdb.com/find/?q=',
  bing: 'https://www.bing.com/search?q=',
  duckduckgo: 'https://duckduckgo.com/?q='
};
const ENGINE_ALIAS = { 'google maps': 'maps', 'x': 'twitter' };


/* ---------------------------------------------------------------------
   3. Audio, speech output, speech input
   --------------------------------------------------------------------- */
let actx = null;
function audio() {
  if (!actx) { try { actx = new (window.AudioContext || window.webkitAudioContext)(); } catch { /* no audio */ } }
  if (actx && actx.state === 'suspended') actx.resume();
  return actx;
}
function tone(freq, dur = .12, when = 0, type = 'sine', vol = .05) {
  const c = audio(); if (!c) return;
  const o = c.createOscillator(), g = c.createGain();
  o.type = type; o.frequency.value = freq;
  const t = c.currentTime + when;
  g.gain.setValueAtTime(0, t);
  g.gain.linearRampToValueAtTime(vol, t + .01);
  g.gain.exponentialRampToValueAtTime(.0001, t + dur);
  o.connect(g).connect(c.destination);
  o.start(t); o.stop(t + dur + .02);
}
const chime = () => { tone(659, .10, 0); tone(988, .16, .09); };
const alarm = () => { for (let i = 0; i < 5; i++) { tone(880, .14, i * .35, 'square', .04); tone(660, .14, i * .35 + .17, 'square', .04); } };

/* ----- app state ----- */
let state = 'off';            // off | standby | awake | thinking | speaking
let micOn = false;
let paused = false;           // recognition paused while Jarvis talks
let speaking = false;
let busy = false;
let awakeUntil = 0;
let awakeTimer = null;

const STATUS = {
  off: () => SR ? 'Microphone off' : 'Voice input isn’t available in this browser. Type below.',
  standby: () => `Say “${cap(settings.wake)}” to wake me`,
  awake: () => 'Listening…',
  thinking: () => 'On it…',
  speaking: () => 'Speaking'
};
function setState(s) {
  state = s;
  document.body.dataset.state = s;
  el.status.textContent = STATUS[s]();
  const pill = $('#pill'); if (pill) pill.textContent = { off: 'Mic off', standby: 'Standby', awake: 'Listening', thinking: 'Thinking', speaking: 'Speaking' }[s];
  Brain.setMode({ off: 'idle', standby: 'standby', awake: 'listening', thinking: 'thinking', speaking: 'speaking' }[s]);
}
function rest() {
  if (busy) return setState('thinking');
  if (speaking) return;
  setState(micOn ? (Date.now() < awakeUntil ? 'awake' : 'standby') : 'off');
}
function extendAwake(ms) {
  awakeUntil = Date.now() + ms;
  clearTimeout(awakeTimer);
  awakeTimer = setTimeout(() => { if (!speaking && !busy) rest(); }, ms + 80);
  if (micOn && !speaking && !busy) setState('awake');
}

/* ----- speech output ----- */
let voices = [];
function loadVoices() {
  if (!('speechSynthesis' in window)) return;
  voices = speechSynthesis.getVoices();
  const sel = $('#sVoice');
  if (sel) {
    sel.innerHTML = '<option value="">Automatic (British male if available)</option>' +
      voices.map(v => `<option value="${esc(v.name)}">${esc(v.name)} (${esc(v.lang)})</option>`).join('');
    sel.value = settings.voice || '';
  }
}
if ('speechSynthesis' in window) { speechSynthesis.onvoiceschanged = loadVoices; loadVoices(); }

function pickVoice() {
  if (settings.voice) { const v = voices.find(v => v.name === settings.voice); if (v) return v; }
  const en = voices.filter(v => /^en/i.test(v.lang));
  const gb = en.filter(v => /en[-_]GB/i.test(v.lang));
  const male = /Daniel|Google UK English Male|Ryan|George|Arthur|Oliver|Rishi|Thomas/i;
  return gb.find(v => male.test(v.name)) || gb[0] || en.find(v => /Alex|David|Mark|Fred/i.test(v.name)) || en[0] || null;
}

function speak(text) {
  return new Promise(resolve => {
    if (!('speechSynthesis' in window)) return resolve();
    const clean = String(text).replace(/\s+/g, ' ').trim();
    if (!clean) return resolve();
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(clean);
    const v = pickVoice();
    if (v) { u.voice = v; u.lang = v.lang; }
    u.rate = settings.rate; u.pitch = settings.pitch;

    let started = false, done = false, guard;
    const t0 = Date.now();
    const finish = () => {
      if (done) return; done = true;
      clearInterval(guard);
      speaking = false;
      resumeListening();
      rest();
      resolve();
    };
    u.onstart = () => { started = true; speaking = true; setState('speaking'); pauseListening(); Brain.emit('language', `Speaking: “${clean.slice(0, 60)}${clean.length > 60 ? '…' : ''}”`, .7); };
    u.onend = finish;
    u.onerror = finish;
    // Some browsers never fire onend for long phrases, so double-check.
    guard = setInterval(() => {
      if ((started && !speechSynthesis.speaking) || (!started && Date.now() - t0 > 4000)) finish();
    }, 400);
    speechSynthesis.speak(u);
  });
}

/* ----- speech input with wake word ----- */
let rec = null, recRunning = false, errShown = {};

function wakeRe() {
  const w = (settings.wake || 'jarvis').trim().toLowerCase();
  const alts = w === 'jarvis' ? ['jarvis', 'jarvus', 'jarves', 'jervis', 'garvis', 'yarvis', 'travis'] : [w];
  return new RegExp('\\b(' + alts.map(escRe).join('|') + ')\\b', 'i');
}

function initRec() {
  if (!SR || rec) return !!rec;
  rec = new SR();
  rec.continuous = true;
  rec.interimResults = true;
  rec.maxAlternatives = 1;
  rec.lang = /^en/i.test(navigator.language) ? navigator.language : 'en-US';

  rec.onresult = e => {
    let interim = '', final = '';
    for (let i = e.resultIndex; i < e.results.length; i++) {
      const r = e.results[i];
      (r.isFinal ? (final += r[0].transcript) : (interim += r[0].transcript));
    }
    if (interim) showHeard(interim);
    if (final) { showHeard(final); onUtterance(final.trim()); }
  };
  rec.onerror = e => {
    if (e.error === 'not-allowed' || e.error === 'service-not-allowed') {
      micOn = false; setState('off'); syncMicBtn();
      if (!errShown.perm) { errShown.perm = 1; log('jarvis', 'The browser blocked microphone access. Click the lock icon in the address bar, allow the microphone, then press Mic on.'); }
    } else if (e.error === 'audio-capture') {
      micOn = false; setState('off'); syncMicBtn();
      if (!errShown.cap) { errShown.cap = 1; log('jarvis', 'I can’t find a working microphone. Check that one is connected and not in use by another app.'); }
    } else if (e.error === 'network') {
      if (!errShown.net) { errShown.net = 1; log('jarvis', 'Your browser’s speech service can’t be reached. Voice recognition needs an internet connection. Typing still works.'); }
    }
    // 'no-speech' and 'aborted' are normal
  };
  rec.onend = () => {
    recRunning = false;
    if (micOn && !paused) setTimeout(startRec, 300);
  };
  return true;
}
function startRec() {
  if (!micOn || paused || recRunning || !initRec()) return;
  try { rec.start(); recRunning = true; } catch { /* already started */ }
}
function pauseListening() { paused = true; if (rec) { try { rec.abort(); } catch { /* ignore */ } } }
function resumeListening() { paused = false; if (micOn) setTimeout(startRec, 250); }

function startMic() {
  if (!SR) return;
  micOn = true; paused = false;
  syncMicBtn(); rest();
  startMeter();
  startRec();
}
function stopMic() {
  micOn = false;
  if (rec) { try { rec.abort(); } catch { /* ignore */ } }
  stopMeter(); awakeUntil = 0;
  syncMicBtn(); rest();
}
function syncMicBtn() {
  el.micBtn.textContent = micOn ? 'Mic on' : 'Mic off';
  el.micBtn.setAttribute('aria-pressed', String(micOn));
  Brain.setVital('voice', micOn ? `Listening for “${cap(settings.wake)}”` : 'Off');
}

let heardTimer;
function showHeard(t) {
  el.heard.textContent = `“${t}”`;
  el.heard.classList.add('show');
  clearTimeout(heardTimer);
  heardTimer = setTimeout(() => el.heard.classList.remove('show'), 4500);
}

function onUtterance(raw) {
  if (busy) return;
  const m = raw.match(wakeRe());
  const awake = Date.now() < awakeUntil;
  if (!m && !awake) return;                     // ordinary chatter: ignore
  Brain.emit('hearing', m ? 'Wake word heard' : 'Follow-up heard', m ? .9 : .5);

  let cmd = m ? raw.slice(m.index + m[0].length) : raw;
  cmd = cmd.replace(/^[\s,.:;!?-]+/, '').trim();
  if (m && !cmd && m.index > 0) cmd = raw.slice(0, m.index).replace(/[\s,.:;!?-]+$/, '').trim();  // “open youtube, Jarvis”
  if (m && !cmd) return wakeUp();
  handleCommand(cmd, { viaWake: !!m });
}

function wakeUp() {
  chime();
  extendAwake(9000);
  if (settings.ackVoice) respond({ say: pick(['Yes, ' + sir() + '?', 'At your service.', 'I’m listening.', 'Go ahead.']) });
}

/* ----- orb reacts to sound (mic level, or a pulse while speaking) ----- */
let meter = null, level = 0;
async function startMeter() {
  if (!settings.orbMic || meter || !navigator.mediaDevices?.getUserMedia) return;
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } });
    const c = audio();
    if (!c) { stream.getTracks().forEach(t => t.stop()); return; }
    const an = c.createAnalyser(); an.fftSize = 256;
    c.createMediaStreamSource(stream).connect(an);
    meter = { stream, an, data: new Uint8Array(an.fftSize) };
  } catch { /* permission is reported by speech recognition */ }
}
function stopMeter() { if (meter) { meter.stream.getTracks().forEach(t => t.stop()); meter = null; } }

function orbLoop(now) {
  let target = 0;
  if (speaking) target = .3 + .55 * Math.abs(Math.sin(now / 130) * Math.sin(now / 370 + 1));
  else if (meter && micOn) {
    meter.an.getByteTimeDomainData(meter.data);
    let sum = 0; for (const v of meter.data) { const x = (v - 128) / 128; sum += x * x; }
    target = Math.min(1, Math.sqrt(sum / meter.data.length) * 5) * (state === 'awake' ? 1 : .6);
  } else if (state === 'thinking') target = .3;
  level += (target - level) * .18;
  el.orb.style.setProperty('--level', level.toFixed(3));
  requestAnimationFrame(orbLoop);
}

(function buildOrb() {
  let t = '', c = '';
  for (let i = 0; i < 72; i++) t += `<line x1="0" y1="-190" x2="0" y2="${-190 + (i % 6 === 0 ? 14 : 6)}" transform="rotate(${i * 5})"/>`;
  for (let i = 0; i < 10; i++) c += `<rect class="coil" x="-11" y="-104" width="22" height="34" rx="4" transform="rotate(${i * 36})" style="--i:${i}"/>`;
  $('#ticks').innerHTML = t;
  $('#coils').innerHTML = c;
})();


/* ---------------------------------------------------------------------
   4. Panels: log, timers, tasks, weather, device
   --------------------------------------------------------------------- */
function log(who, text, links = []) {
  const d = document.createElement('div');
  d.className = 'msg ' + who;
  d.innerHTML = `<span class="who">${who === 'user' ? 'You' : 'Jarvis'}</span><p>${esc(text)}</p>`;
  for (const l of links) {
    const a = document.createElement('a');
    a.className = 'chip'; a.href = l.url; a.target = '_blank'; a.rel = 'noopener noreferrer';
    a.textContent = l.label; a.title = l.url;
    d.appendChild(a);
  }
  el.log.appendChild(d);
  while (el.log.children.length > 80) el.log.firstChild.remove();
  el.log.parentElement.scrollTop = el.log.parentElement.scrollHeight;
}

/* ----- timers ----- */
let timers = store.get('timers', []).filter(t => t.end > Date.now());
function fmtDur(s) {
  const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), x = s % 60, p = [];
  if (h) p.push(`${h} hour${h > 1 ? 's' : ''}`);
  if (m) p.push(`${m} minute${m > 1 ? 's' : ''}`);
  if (x && !h) p.push(`${x} second${x > 1 ? 's' : ''}`);
  return p.join(' and ') || '0 seconds';
}
function fmtClock(ms) {
  const s = Math.max(0, Math.ceil(ms / 1000)), h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), x = s % 60;
  return (h ? h + ':' : '') + String(m).padStart(h ? 2 : 1, '0') + ':' + String(x).padStart(2, '0');
}
function addTimer(secs, label = '') {
  timers.push({ id: Date.now() + Math.random(), end: Date.now() + secs * 1000, secs, label });
  store.set('timers', timers); renderTimers();
  Brain.emit('reflex', `Timer set: ${label || fmtDur(secs)}`);
  const d = fmtDur(secs);
  return { say: label ? `Understood. I’ll remind you to ${label} in ${d}.` : `Timer set for ${d}.` };
}
function renderTimers() {
  $('#timers').innerHTML = timers.map(t =>
    `<li><span class="grow">${esc(t.label || fmtDur(t.secs))}</span><span class="time">${fmtClock(t.end - Date.now())}</span><button class="icon-btn" data-id="${t.id}" aria-label="Cancel timer">×</button></li>`).join('');
  $('#timersEmpty').hidden = timers.length > 0;
}
$('#timers').addEventListener('click', e => {
  const b = e.target.closest('button'); if (!b) return;
  timers = timers.filter(t => String(t.id) !== b.dataset.id); store.set('timers', timers); renderTimers();
});
function tickTimers() {
  const due = timers.filter(t => t.end <= Date.now());
  if (due.length) {
    timers = timers.filter(t => t.end > Date.now()); store.set('timers', timers);
    alarm();
    Brain.emit('reflex', 'Timer fired', 1.2);
    (async () => { for (const t of due) await respond({ say: t.label ? `${cap(sir())}, a reminder: ${t.label}.` : `${cap(sir())}, your ${fmtDur(t.secs)} timer is up.` }); })();
  }
  renderTimers();
}

const ONES = { zero: 0, one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9, ten: 10, eleven: 11, twelve: 12, thirteen: 13, fourteen: 14, fifteen: 15, sixteen: 16, seventeen: 17, eighteen: 18, nineteen: 19 };
const TENS = { twenty: 20, thirty: 30, forty: 40, fifty: 50, sixty: 60, seventy: 70, eighty: 80, ninety: 90 };
const NUM_RE = new RegExp(`\\b(?:(?:${Object.keys(TENS).join('|')})(?:[\\s-](?:one|two|three|four|five|six|seven|eight|nine))?|${Object.keys(ONES).join('|')})\\b`, 'g');
function wordsToDigits(s) {
  return s.replace(NUM_RE, m => String(m.split(/[\s-]/).reduce((a, w) => a + (ONES[w] ?? TENS[w] ?? 0), 0)));
}
function parseDuration(s) {
  s = wordsToDigits(s.toLowerCase())
    .replace(/half an hour|half hour/g, '30 minutes')
    .replace(/(\d+) and a half (hours?|minutes?)/g, (m, n, u) => `${+n + .5} ${u}`)
    .replace(/\ban? (?=hour|minute|second|min|sec|hr)/g, '1 ');
  let total = 0, found = false;
  s.replace(/(\d+(?:\.\d+)?)\s*(hours?|hrs?|h|minutes?|mins?|m|seconds?|secs?|s)\b/g, (m, n, u) => {
    found = true; n = parseFloat(n);
    total += /^h/.test(u) ? n * 3600 : /^m/.test(u) ? n * 60 : n; return m;
  });
  if (!found) { const b = s.match(/^\s*(\d+)\s*$/); if (b) { total = +b[1] * 60; found = true; } }
  return found ? Math.round(total) : 0;
}

/* ----- tasks ----- */
let tasks = store.get('tasks', []);
const saveTasks = () => { store.set('tasks', tasks); renderTasks(); };
function renderTasks() {
  $('#tasks').innerHTML = tasks.length ? tasks.map(t =>
    `<li class="${t.done ? 'done' : ''}"><input type="checkbox" data-id="${t.id}" ${t.done ? 'checked' : ''} aria-label="Done"><span class="grow">${esc(t.text)}</span><button class="icon-btn" data-del="${t.id}" aria-label="Delete task">×</button></li>`).join('')
    : '<li class="muted">Nothing on the list.</li>';
}
$('#tasks').addEventListener('click', e => {
  const cb = e.target.closest('input[type="checkbox"]'), del = e.target.closest('[data-del]');
  if (cb) { const t = tasks.find(t => String(t.id) === cb.dataset.id); if (t) { t.done = cb.checked; saveTasks(); } }
  if (del) { tasks = tasks.filter(t => String(t.id) !== del.dataset.del); saveTasks(); }
});
$('#taskForm').addEventListener('submit', e => {
  e.preventDefault();
  const v = $('#taskInput').value.trim(); if (!v) return;
  addTask(v); $('#taskInput').value = '';
});
function addTask(text) { tasks.push({ id: Date.now() + Math.random(), text: cap(text), done: false }); saveTasks(); Brain.emit('memory', `Task added: ${text.slice(0, 50)}`); }

/* ----- notes live in the virtual file system ----- */
function addNote(text) {
  const stamp = new Date().toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
  const p = '/home/jarvis/notes.txt';
  Brain.emit('memory', `Note saved: ${text.slice(0, 50)}`);
  fsWrite(p, (fs[p]?.c || '') + `[${stamp}] ${text}\n`);
  winEls.files?.api?.reload();
}

/* ----- weather ----- */
const WMO = { 0: 'clear', 1: 'mostly clear', 2: 'partly cloudy', 3: 'overcast', 45: 'foggy', 48: 'foggy', 51: 'drizzling', 53: 'drizzling', 55: 'drizzling', 56: 'freezing drizzle', 57: 'freezing drizzle', 61: 'lightly raining', 63: 'raining', 65: 'raining heavily', 66: 'freezing rain', 67: 'freezing rain', 71: 'lightly snowing', 73: 'snowing', 75: 'snowing heavily', 77: 'snowing', 80: 'showery', 81: 'showery', 82: 'stormy with heavy showers', 85: 'snow showers', 86: 'snow showers', 95: 'thunderstorming', 96: 'thunderstorming with hail', 99: 'thunderstorming with hail' };
const userErr = m => Object.assign(new Error(m), { user: true });

async function geocode(name) {
  const q = name.split(',')[0].trim();
  let r;
  try { r = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(q)}&count=1&language=en&format=json`); }
  catch { throw userErr('I couldn’t reach the weather service. Check your connection.'); }
  if (!r.ok) throw userErr('I couldn’t reach the weather service.');
  const d = await r.json();
  if (!d.results?.length) throw userErr(`I couldn’t find a place called ${name}.`);
  const x = d.results[0];
  return { name: x.name, lat: x.latitude, lon: x.longitude };
}
async function resolveLocation(place) {
  if (place) return geocode(place);
  if (settings.city) return geocode(settings.city);
  if (settings.coords) return settings.coords;
  const pos = await new Promise((res, rej) => navigator.geolocation ? navigator.geolocation.getCurrentPosition(res, rej, { timeout: 9000 }) : rej(new Error('no geolocation')));
  settings.coords = { name: 'your location', lat: pos.coords.latitude, lon: pos.coords.longitude };
  saveSettings();
  return settings.coords;
}
async function weatherCmd(place) {
  let loc;
  try { loc = await resolveLocation(place); }
  catch (e) { throw e.user ? e : userErr(place || settings.city ? 'I couldn’t reach the weather service.' : 'I need a location. Tell me a city, or set a home city in Settings.'); }
  const F = settings.units === 'F';
  const url = `https://api.open-meteo.com/v1/forecast?latitude=${loc.lat}&longitude=${loc.lon}&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max&temperature_unit=${F ? 'fahrenheit' : 'celsius'}&wind_speed_unit=${F ? 'mph' : 'kmh'}&forecast_days=1&timezone=auto`;
  let d;
  try { const r = await fetch(url); if (!r.ok) throw 0; d = await r.json(); }
  catch { throw userErr('I couldn’t reach the weather service. Check your connection.'); }
  const c = d.current, dl = d.daily;
  const w = {
    place: loc.name, temp: Math.round(c.temperature_2m), feels: Math.round(c.apparent_temperature),
    cond: WMO[c.weather_code] || 'unsettled', hi: Math.round(dl.temperature_2m_max[0]), lo: Math.round(dl.temperature_2m_min[0]),
    rain: dl.precipitation_probability_max?.[0], wind: Math.round(c.wind_speed_10m), unit: F ? '°F' : '°C'
  };
  renderWeather(w);
  Brain.emit('web', `Weather for ${w.place}`);
  const where = w.place === 'your location' ? 'Right now' : `Right now in ${w.place}`;
  let say = `${where}, it’s ${w.temp} degrees${F ? '' : ' Celsius'} and ${w.cond}. Today’s high is ${w.hi}, the low ${w.lo}`;
  if (w.rain != null) say += `, with a ${w.rain} percent chance of rain`;
  return say + '.';
}
function renderWeather(w) {
  $('#weather').innerHTML =
    `<div class="big">${w.temp}<small>${w.unit}</small></div>
     <p>${esc(cap(w.cond))} in ${esc(w.place)}</p>
     <p class="muted">High ${w.hi}° · Low ${w.lo}°${w.rain != null ? ` · Rain ${w.rain}%` : ''} · Wind ${w.wind}</p>`;
}

/* ----- device ----- */
async function sysInfo() {
  const i = { cores: navigator.hardwareConcurrency, mem: navigator.deviceMemory, online: navigator.onLine, net: navigator.connection?.effectiveType };
  try { const b = await navigator.getBattery?.(); if (b) { i.batt = Math.round(b.level * 100); i.charging = b.charging; } } catch { /* unsupported */ }
  return i;
}
const fmtUptime = () => { const m = Math.floor((Date.now() - sessionStart) / 60000); return m < 1 ? 'under a minute' : m < 60 ? `${m} min` : `${Math.floor(m / 60)} h ${m % 60} min`; };
async function renderSys() {
  const s = await sysInfo();
  const rows = [
    ['Network', s.online ? 'Online' : 'Offline'],
    ['Battery', s.batt != null ? `${s.batt}%${s.charging ? ' ⚡' : ''}` : 'Not reported'],
    ['CPU threads', s.cores ?? '—'],
    ['Session', fmtUptime()]
  ];
  $('#sys').innerHTML = rows.map(r => `<dt>${r[0]}</dt><dd>${esc(r[1])}</dd>`).join('');
}


/* ---------------------------------------------------------------------
   5. Virtual workstation: file system, shell, windows
      (a small computer that lives inside the page — safe, and yours to reset)
   --------------------------------------------------------------------- */
const defaultFS = () => ({
  '/': { t: 'd' }, '/home': { t: 'd' }, '/home/jarvis': { t: 'd' }, '/home/jarvis/projects': { t: 'd' }, '/tmp': { t: 'd' },
  '/home/jarvis/notes.txt': { t: 'f', c: '' },
  '/home/jarvis/readme.txt': { t: 'f', c: 'Welcome to your J.A.R.V.I.S. workstation.\n\nThis is a small virtual computer that lives inside this browser tab.\nFiles are saved in this browser only.\n\nTry:  echo hello > ~/hello.txt\n      ls\n      neofetch\n      open youtube\n' }
});
let fs = store.get('fs', null) || defaultFS();
const saveFS = () => store.set('fs', fs);
let cwd = '/home/jarvis';

function fsResolve(p, base = cwd) {
  if (!p) return base;
  if (p === '~') p = '/home/jarvis'; else if (p.startsWith('~/')) p = '/home/jarvis/' + p.slice(2);
  const out = [];
  for (const s of (p.startsWith('/') ? p : base + '/' + p).split('/')) {
    if (!s || s === '.') continue;
    if (s === '..') out.pop(); else out.push(s);
  }
  return '/' + out.join('/');
}
const fsParent = p => p === '/' ? '/' : (p.slice(0, p.lastIndexOf('/')) || '/');
const fsBase = p => p.slice(p.lastIndexOf('/') + 1);
const fsList = dir => Object.keys(fs).filter(k => k !== '/' && fsParent(k) === dir).sort();
function fsWrite(p, content) {
  const par = fsParent(p);
  if (!fs[par] || fs[par].t !== 'd') throw new Error(`${par}: no such directory`);
  if (fs[p] && fs[p].t === 'd') throw new Error(`${p}: is a directory`);
  fs[p] = { t: 'f', c: content }; saveFS();
}

const shellHistory = [];
let termBuf = [
  { c: '', t: 'J.A.R.V.I.S. workstation — a virtual computer that lives in this tab.' },
  { c: '', t: 'Type "help" to see what it can do.\n' }
];
function termPrint(text, cls = '') {
  for (const line of String(text).split('\n')) termBuf.push({ c: cls, t: line });
  if (termBuf.length > 300) termBuf.splice(0, termBuf.length - 300);
  winEls.terminal?.api?.paint();
}

const SHELL = {
  help() {
    return [
      'Files      ls [dir]  cd <dir>  pwd  cat <file>  echo <text> [> file]',
      '           mkdir  touch  rm [-r]  cp  mv  edit <file>  clear',
      'System     date  whoami  uname  neofetch  history  reset',
      'Jarvis     open <site>   search <query>   say <text>   calc <math>',
      '           weather [city]   timer <duration>   note <text>   tasks',
      '           theme <blue|red|gold|green>   ask <question>'
    ].join('\n');
  },
  pwd() { return cwd; },
  ls(a) {
    const p = fsResolve(a[0]);
    if (!fs[p]) throw new Error(`${a[0]}: no such file or directory`);
    if (fs[p].t === 'f') return fsBase(p);
    return fsList(p).map(k => fsBase(k) + (fs[k].t === 'd' ? '/' : '')).join('  ') || '(empty)';
  },
  cd(a) {
    const p = fsResolve(a[0] || '~');
    if (!fs[p] || fs[p].t !== 'd') throw new Error(`${a[0]}: not a directory`);
    cwd = p; winEls.terminal?.api?.setPrompt(); return '';
  },
  cat(a) {
    if (!a[0]) throw new Error('missing file name');
    const p = fsResolve(a[0]);
    if (!fs[p]) throw new Error(`${a[0]}: no such file`);
    if (fs[p].t === 'd') throw new Error(`${a[0]}: is a directory`);
    return fs[p].c.replace(/\n$/, '');
  },
  echo(a) { return a.join(' '); },
  mkdir(a) {
    if (!a[0]) throw new Error('missing name');
    for (const n of a) {
      const p = fsResolve(n);
      if (fs[p]) throw new Error(`${n}: already exists`);
      if (!fs[fsParent(p)] || fs[fsParent(p)].t !== 'd') throw new Error(`${n}: parent directory missing`);
      fs[p] = { t: 'd' };
    }
    saveFS(); return '';
  },
  touch(a) { if (!a[0]) throw new Error('missing name'); for (const n of a) { const p = fsResolve(n); if (!fs[p]) fsWrite(p, ''); } return ''; },
  rm(a) {
    const rec = a.some(x => /^-\w*r/.test(x));
    const names = a.filter(x => !x.startsWith('-'));
    if (!names.length) throw new Error('missing name');
    for (const n of names) {
      const p = fsResolve(n);
      if (['/', '/home', '/home/jarvis'].includes(p)) throw new Error(`${n}: refusing to remove`);
      if (!fs[p]) throw new Error(`${n}: no such file or directory`);
      if (fs[p].t === 'd' && !rec && fsList(p).length) throw new Error(`${n}: directory not empty (use rm -r)`);
      Object.keys(fs).filter(k => k === p || k.startsWith(p + '/')).forEach(k => delete fs[k]);
    }
    saveFS(); return '';
  },
  cp(a) {
    if (a.length < 2) throw new Error('usage: cp <from> <to>');
    const s = fsResolve(a[0]); let d = fsResolve(a[1]);
    if (!fs[s] || fs[s].t !== 'f') throw new Error(`${a[0]}: no such file`);
    if (fs[d]?.t === 'd') d += '/' + fsBase(s);
    fsWrite(d, fs[s].c); return '';
  },
  mv(a) { SHELL.cp(a); SHELL.rm([a[0]]); return ''; },
  edit(a) {
    const p = fsResolve(a[0] || 'notes.txt');
    if (!fs[p]) fsWrite(p, '');
    openApp('files', p); return `Opening ${p} in the editor.`;
  },
  clear() { return '\x0c'; },
  date() { return new Date().toString(); },
  whoami() { return 'guest'; },
  hostname() { return 'jarvis-core'; },
  uname() { return 'JARVIS-OS 1.0 (runs entirely in your browser)'; },
  history() { return shellHistory.map((h, i) => `${String(i + 1).padStart(3)}  ${h}`).join('\n') || '(empty)'; },
  async neofetch() {
    const s = await sysInfo();
    return [
      `guest@jarvis-core`, '------------------',
      `OS:        JARVIS-OS 1.0 (browser)`,
      `Uptime:    ${fmtUptime()}`,
      `CPU:       ${s.cores ?? '?'} threads`,
      `Memory:    ${s.mem ? s.mem + ' GB+' : 'unknown'}`,
      `Battery:   ${s.batt != null ? s.batt + '%' : 'n/a'}`,
      `Network:   ${s.online ? 'online' : 'offline'}`,
      `Files:     ${Object.values(fs).filter(x => x.t === 'f').length}`,
      `Voice in:  ${SR ? 'yes' : 'no'}   Voice out: ${'speechSynthesis' in window ? 'yes' : 'no'}`
    ].join('\n');
  },
  open(a) { if (!a.length) throw new Error('usage: open <site>'); const r = openSiteByName(a.join(' ')); return r.say + (r.links?.[0] ? '\n' + r.links[0].url : ''); },
  search(a) { if (!a.length) throw new Error('usage: search <query>'); const r = doSearch(a.join(' ')); return r.say + '\n' + r.links[0].url; },
  say(a) { speak(a.join(' ')); return ''; },
  calc(a) { const r = tryMath(a.join(' ')); if (!r) throw new Error('could not evaluate that'); return r.say; },
  async weather(a) { try { return await weatherCmd(a.join(' ')); } catch (e) { throw new Error(e.message); } },
  timer(a) { const s = parseDuration(a.join(' ')); if (!s) throw new Error('usage: timer 5 minutes'); return addTimer(s).say; },
  note(a) { if (!a.length) throw new Error('usage: note <text>'); addNote(a.join(' ')); return 'Saved to /home/jarvis/notes.txt'; },
  tasks() { return tasks.map((t, i) => `${i + 1}. [${t.done ? 'x' : ' '}] ${t.text}`).join('\n') || 'No tasks.'; },
  theme(a) { const t = (a[0] || '').toLowerCase(); if (!['blue', 'red', 'gold', 'green'].includes(t)) throw new Error('usage: theme blue|red|gold|green'); setTheme(t); return `Theme set to ${t}.`; },
  async ask(a) {
    if (!aiReady()) throw new Error('no AI key. Add one to secrets.txt or Settings to enable "ask".');
    const { clean } = applyTags(await askClaude(a.join(' ')));
    return clean;
  },
  reset() { fs = defaultFS(); saveFS(); cwd = '/home/jarvis'; winEls.terminal?.api?.setPrompt(); winEls.files?.api?.reload(); return 'Workstation reset to its original state.'; }
};

async function runShell(line) {
  line = line.trim(); if (!line) return '';
  let redirect = null;
  const rm = line.match(/^(.*?)\s*(>>|>)\s*(\S+)\s*$/);
  if (rm && !/^(ask|say|note|search|open)\b/i.test(line)) { line = rm[1]; redirect = { append: rm[2] === '>>', path: fsResolve(rm[3]) }; }
  const args = (line.match(/"[^"]*"|'[^']*'|\S+/g) || []).map(a => /^(["']).*\1$/.test(a) ? a.slice(1, -1) : a);
  const cmd = (args.shift() || '').toLowerCase();
  const fn = Object.prototype.hasOwnProperty.call(SHELL, cmd) ? SHELL[cmd] : null;
  if (!fn) return { err: `${cmd}: command not found. Type "help".` };
  let out;
  try { out = await fn(args); } catch (e) { return { err: `${cmd}: ${e.message}` }; }
  if (redirect && typeof out === 'string') {
    try { fsWrite(redirect.path, (redirect.append ? (fs[redirect.path]?.c || '') : '') + out + '\n'); winEls.files?.api?.reload(); return ''; }
    catch (e) { return { err: `${cmd}: ${e.message}` }; }
  }
  return out ?? '';
}
async function runInTerminal(line) {
  openApp('terminal');
  termPrint(`${promptText()} ${line}`, 'cmd');
  const r = await runShell(line);
  if (r && r.err) termPrint(r.err, 'err'); else if (r === '\x0c') termBuf.length = 0; else if (r) termPrint(r);
  winEls.terminal?.api?.paint();
  return r;
}
const promptText = () => `jarvis@core:${cwd.replace('/home/jarvis', '~')}$`;

/* ----- window manager ----- */
const winEls = {};
let zTop = 40, cascade = 0;
function openWindow(id, { title, w = 540, h = 360, render }, arg) {
  if (winEls[id]) { focusWin(winEls[id].el); winEls[id].api?.open?.(arg); return winEls[id]; }
  const win = document.createElement('section');
  win.className = 'win'; win.setAttribute('role', 'dialog'); win.setAttribute('aria-label', title);
  win.style.width = Math.min(w, innerWidth - 20) + 'px';
  win.style.height = Math.min(h, innerHeight - 90) + 'px';
  win.style.left = Math.max(8, Math.min(innerWidth - w - 8, innerWidth * 0.26 + cascade * 34)) + 'px';
  win.style.top = Math.max(8, Math.min(innerHeight - h - 8, 80 + cascade * 34)) + 'px';
  cascade = (cascade + 1) % 6;
  win.innerHTML = `<header class="win-bar"><span>${esc(title)}</span><button class="win-x" aria-label="Close ${esc(title)}">×</button></header><div class="win-body"></div>`;
  $('#windows').appendChild(win);
  const entry = winEls[id] = { el: win, api: null };
  entry.api = render($('.win-body', win), arg) || {};

  const bar = $('.win-bar', win);
  bar.addEventListener('pointerdown', e => {
    if (e.target.closest('button')) return;
    focusWin(win);
    const r = win.getBoundingClientRect(), dx = e.clientX - r.left, dy = e.clientY - r.top;
    bar.setPointerCapture(e.pointerId);
    const move = ev => {
      win.style.left = Math.max(0, Math.min(innerWidth - 80, ev.clientX - dx)) + 'px';
      win.style.top = Math.max(0, Math.min(innerHeight - 40, ev.clientY - dy)) + 'px';
    };
    const up = () => { bar.removeEventListener('pointermove', move); bar.removeEventListener('pointerup', up); };
    bar.addEventListener('pointermove', move); bar.addEventListener('pointerup', up);
  });
  win.addEventListener('pointerdown', () => focusWin(win));
  $('.win-x', win).addEventListener('click', () => closeWin(id));
  focusWin(win);
  entry.api.focus?.();
  return entry;
}
function focusWin(w) { w.style.zIndex = ++zTop; }
function closeWin(id) { const w = winEls[id]; if (!w) return; w.api?.close?.(); w.el.remove(); delete winEls[id]; }
function closeAllWins() { Object.keys(winEls).forEach(closeWin); }

const APPS = {
  terminal: { title: 'Workstation — terminal', w: 580, h: 380, render: appTerminal },
  files: { title: 'Files', w: 660, h: 400, render: appFiles },
  monitor: { title: 'System monitor', w: 420, h: 400, render: appMonitor }
};
function openApp(name, arg) { return openWindow(name, APPS[name], arg); }

function appTerminal(body) {
  body.innerHTML = `<div class="term"><div class="term-out" tabindex="0" aria-live="polite"></div><form class="term-in" autocomplete="off"><span class="prompt"></span><input spellcheck="false" autocapitalize="off" aria-label="Terminal command"></form></div>`;
  const out = $('.term-out', body), form = $('.term-in', body), input = $('input', form), prompt = $('.prompt', form);
  let hi = shellHistory.length;
  const api = {
    paint() { out.innerHTML = termBuf.map(l => `<div class="${l.c}">${esc(l.t) || '&nbsp;'}</div>`).join(''); out.scrollTop = out.scrollHeight; },
    setPrompt() { prompt.textContent = promptText(); },
    focus() { input.focus(); }
  };
  form.addEventListener('submit', async e => {
    e.preventDefault();
    const v = input.value; input.value = '';
    if (v.trim()) shellHistory.push(v);
    hi = shellHistory.length;
    termPrint(`${promptText()} ${v}`, 'cmd');
    const r = await runShell(v);
    if (r && r.err) termPrint(r.err, 'err'); else if (r === '\x0c') termBuf.length = 0; else if (r) termPrint(r);
    api.paint(); api.setPrompt();
  });
  input.addEventListener('keydown', e => {
    if (e.key === 'ArrowUp') { e.preventDefault(); hi = Math.max(0, hi - 1); input.value = shellHistory[hi] || ''; }
    if (e.key === 'ArrowDown') { e.preventDefault(); hi = Math.min(shellHistory.length, hi + 1); input.value = shellHistory[hi] || ''; }
  });
  body.addEventListener('click', e => { if (!getSelection().toString()) input.focus(); });
  api.paint(); api.setPrompt();
  return api;
}

function appFiles(body, arg) {
  body.innerHTML = `<div class="files"><ul class="files-list" aria-label="Files"></ul><div class="files-edit">
    <div class="files-bar"><span class="files-path"></span><span class="files-actions"><button class="btn sm" data-a="new">New</button><button class="btn sm" data-a="save">Save</button><button class="btn sm" data-a="del">Delete</button></span></div>
    <textarea spellcheck="false" aria-label="File contents"></textarea><div class="files-msg" role="status"></div></div></div>`;
  const list = $('.files-list', body), ta = $('textarea', body), pathEl = $('.files-path', body), msg = $('.files-msg', body);
  let cur = null;
  const renderList = () => {
    const files = Object.keys(fs).filter(k => fs[k].t === 'f').sort();
    list.innerHTML = files.map(f => `<li><button data-p="${esc(f)}" class="${f === cur ? 'on' : ''}">${esc(f.replace('/home/jarvis/', '~/'))}</button></li>`).join('');
  };
  const show = () => {
    if (cur && fs[cur]) { ta.value = fs[cur].c; ta.disabled = false; pathEl.textContent = cur; }
    else { cur = null; ta.value = ''; ta.disabled = true; pathEl.textContent = 'No file open'; }
    renderList();
  };
  const api = {
    open(p) { if (p && fs[p] && fs[p].t === 'f') { cur = p; msg.textContent = ''; show(); } },
    reload() { show(); },
    focus() { ta.focus(); }
  };
  const save = () => { if (cur) { fs[cur].c = ta.value; saveFS(); msg.textContent = 'Saved.'; } };
  list.addEventListener('click', e => { const b = e.target.closest('button'); if (b) api.open(b.dataset.p); });
  body.addEventListener('click', e => {
    const a = e.target.closest('[data-a]')?.dataset.a; if (!a) return;
    if (a === 'save') save();
    if (a === 'new') {
      const name = prompt('New file path, for example ~/todo.txt'); if (!name) return;
      const p = fsResolve(name.trim(), '/home/jarvis');
      try { if (!fs[p]) fsWrite(p, ''); api.open(p); } catch (err) { msg.textContent = err.message; }
    }
    if (a === 'del' && cur && confirm(`Delete ${cur}?`)) { delete fs[cur]; saveFS(); cur = null; show(); }
  });
  ta.addEventListener('keydown', e => { if ((e.ctrlKey || e.metaKey) && e.key === 's') { e.preventDefault(); save(); } });
  cur = (arg && fs[arg]) ? arg : '/home/jarvis/notes.txt';
  show();
  return api;
}

function appMonitor(body) {
  body.innerHTML = '<table class="mon"><tbody></tbody></table>';
  const tb = $('tbody', body);
  const paint = async () => {
    const s = await sysInfo();
    const rows = [
      ['Session uptime', fmtUptime()],
      ['CPU threads', s.cores ?? 'unknown'],
      ['Device memory', s.mem ? `${s.mem} GB or more` : 'unknown'],
      ['Battery', s.batt != null ? `${s.batt}%${s.charging ? ' (charging)' : ''}` : 'not reported'],
      ['Network', s.online ? `online${s.net ? ` (${s.net})` : ''}` : 'offline'],
      ['Screen', `${screen.width} × ${screen.height}`],
      ['Time zone', Intl.DateTimeFormat().resolvedOptions().timeZone],
      ['Speech input', SR ? 'available' : 'not supported'],
      ['Speech output', 'speechSynthesis' in window ? 'available' : 'not supported'],
      ['Files stored', Object.values(fs).filter(x => x.t === 'f').length]
    ];
    if (performance.memory) rows.splice(2, 0, ['Page memory', `${Math.round(performance.memory.usedJSHeapSize / 1048576)} MB`]);
    tb.innerHTML = rows.map(r => `<tr><th>${esc(r[0])}</th><td>${esc(r[1])}</td></tr>`).join('');
  };
  paint();
  const id = setInterval(paint, 2000);
  return { close() { clearInterval(id); } };
}


/* ---------------------------------------------------------------------
   6. Command router — what Jarvis understands
   --------------------------------------------------------------------- */
function openUrl(url, label) {
  let ok = false;
  let host = url; try { host = new URL(url).hostname.replace(/^www\./, ''); } catch { /* keep */ }
  Brain.emit('web', `Opening ${host}`, .9);
  if (window.logAction) window.logAction(`Opened ${host}`);
  if (core.online && settings.coreOpen) {
    // The local core opens it in your default browser, so pop-up blockers don't apply.
    ok = true;
    corePost('/api/open-url', { url }).then(r => { if (!r.ok) throw 0; }).catch(() => { try { window.open(url, '_blank'); } catch { /* blocked */ } });
  } else {
    try { const w = window.open(url, '_blank'); if (w) { try { w.opener = null; } catch { /* cross-origin */ } ok = true; } } catch { /* blocked */ }
  }
  return { ok, url, link: { url, label: label || host } };
}
const BLOCKED = name => `I tried to open ${name}, but your browser blocked the pop-up. Use the link below, and allow pop-ups for this page so I can do it by voice.`;

const PRETTY = { youtube: 'YouTube', github: 'GitHub', linkedin: 'LinkedIn', tiktok: 'TikTok', whatsapp: 'WhatsApp', imdb: 'IMDb', ebay: 'eBay', paypal: 'PayPal', chatgpt: 'ChatGPT', duckduckgo: 'DuckDuckGo', gmail: 'Gmail', onedrive: 'OneDrive', 'stack overflow': 'Stack Overflow', 'hacker news': 'Hacker News' };
const prettyName = n => PRETTY[n] || titleCase(n);

function openSiteByName(raw) {
  let n = raw.toLowerCase().trim()
    .replace(/^(?:the|my)\s+/, '')
    .replace(/\s+(?:website|site|web ?page|page|app|web app|for me)$/, '')
    .replace(/\s+dot\s+/g, '.').replace(/\s*\.\s*/g, '.').trim();
  let url = SITES[n], guessed = false;
  const squashed = n.replace(/\s+/g, '');
  if (!url && /^[\w-]+(?:\.[\w-]+)+(?:\/\S*)?$/.test(squashed)) url = 'https://' + squashed;
  if (!url && /^[a-z0-9 ]{2,30}$/.test(n)) { url = `https://www.${squashed}.com`; guessed = true; }
  if (!url) return { say: `I don’t know how to open “${raw}”.` };
  const name = SITES[n] ? prettyName(n) : (url.replace(/^https?:\/\/(www\.)?/, ''));
  const r = openUrl(url, name);
  const say = r.ok ? (guessed ? `Trying ${name}. That’s my best guess at the address.` : `Opening ${name}.`) : BLOCKED(name);
  return { say, links: [r.link], url, ok: r.ok };
}

function doSearch(q, engine = 'google') {
  engine = ENGINE_ALIAS[engine] || engine;
  const url = (ENGINES[engine] || ENGINES.google) + encodeURIComponent(q);
  const r = openUrl(url, `${prettyName(engine)}: ${q}`);
  const say = r.ok ? (engine === 'google' ? `Searching for ${q}.` : `Searching ${prettyName(engine)} for ${q}.`) : BLOCKED('that search');
  return { say, links: [r.link], ok: r.ok };
}

function setTheme(t) { document.body.dataset.theme = t; store.set('theme', t); Brain.refreshColors(); }

function fmtNum(v) { return String(Number(v.toFixed(6))); }
function tryMath(t) {
  let s = wordsToDigits(t.toLowerCase()).replace(/^(?:what is|what's|whats|calculate|compute|how much is|solve|equals?)\s+/, '');
  const sq = s.match(/^(?:the )?square root of (\d+(?:\.\d+)?)$/);
  if (sq) return { say: `The square root of ${sq[1]} is ${fmtNum(Math.sqrt(+sq[1]))}.` };
  s = s.replace(/(\d+(?:\.\d+)?)\s*(?:percent|%) of\s*(\d+(?:\.\d+)?)/g, '($1/100*$2)')
    .replace(/(\d),(\d{3})/g, '$1$2')
    .replace(/\b(?:multiplied by|times|x)\b/g, '*').replace(/\b(?:divided by|over)\b/g, '/')
    .replace(/\bplus\b/g, '+').replace(/\bminus\b/g, '-')
    .replace(/\b(?:to the power of|to the)\b/g, '**').replace(/\bsquared\b/g, '**2').replace(/\bcubed\b/g, '**3')
    .replace(/\bmod(?:ulo)?\b/g, '%').replace(/(\d)\s*point\s*(\d)/g, '$1.$2')
    .replace(/\s+/g, ' ').trim();
  if (!/\d/.test(s) || !/[+\-*/%]/.test(s) || !/^[\d+\-*/%().\s]+$/.test(s)) return null;
  try {
    const v = Function('"use strict";return (' + s + ')')();
    if (typeof v !== 'number') return null;
    if (!isFinite(v)) return { say: 'That one is undefined, ' + sir() + '.' };
    return { say: `That comes to ${fmtNum(v)}.` };
  } catch { return null; }
}

const JOKES = [
  'I would tell you a UDP joke, but you might not get it.',
  'Why do programmers prefer dark mode? Because light attracts bugs.',
  'There are 10 kinds of people: those who understand binary, and those who don’t.',
  'A SQL query walks into a bar, walks up to two tables and asks, “May I join you?”',
  'Why did the developer go broke? He used up all his cache.',
  'I’d tell you a joke about the cloud, but it would go right over your head.',
  'My favourite thing about Mondays is that they are reliably followed by Tuesdays. It’s a low bar, but it clears it.'
];

const greetWord = () => { const h = new Date().getHours(); return h < 5 ? 'Good evening' : h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening'; };

const HELP_TEXT = `Try saying:
• “Open YouTube” — or any website
• “Search for pizza near me” · “Play lo-fi on YouTube”
• “What’s the weather in Tokyo?”
• “Set a timer for 10 minutes” · “Remind me in an hour to stretch”
• “Take a note: call the plumber” · “Add milk to my to-do list”
• “What’s 15 percent of 240?”
• “Open workstation” — my virtual computer
• “System status” · “Tell me a joke” · “Suit up”
• “Show me your brain” · “List my commands” · “Launch calculator”
Stay in the conversation for a few seconds after I answer and you can skip the wake word.`;

const TASK_WORDS = '(?:tasks?|to[ -]?do(?: list)?s?|todos?(?: list)?)';
const WIN_VERB = '(?:open|show|launch|start|bring up|pull up)';

const INTENTS = [
  // ---- control
  [/^(?:stop listening|go to sleep|go quiet|sleep|mute (?:the )?mic(?:rophone)?|turn off (?:the )?mic(?:rophone)?|that'?s all(?: for now)?)$/,
    () => ({ say: `Very well. I’ll go quiet. Press Mic on when you need me.`, after: stopMic })],
  [/^(?:stop|be quiet|quiet|shut up|cancel|never ?mind)$/, () => { speechSynthesis.cancel(); return { silent: true }; }],
  [/^(?:speak|talk) (faster|slower)$/, m => { settings.rate = Math.max(.7, Math.min(1.4, settings.rate + (m[1] === 'faster' ? .15 : -.15))); saveSettings(); return { say: `Speaking ${m[1]} now.` }; }],

  // ---- small talk
  [/^(?:hello|hi|hey|hey there|greetings|good (?:morning|afternoon|evening|night))(?: jarvis| there)?$/, () => ({ say: `${greetWord()}, ${sir()}. How can I help?` })],
  [/^(?:thanks|thank you|cheers)(?: jarvis| very much| so much)?$/, () => ({ say: pick([`You’re welcome, ${sir()}.`, 'Any time.', 'My pleasure.']) })],
  [/^(?:how are you|how are you doing|how'?s it going|what'?s up)$/, () => ({ say: `All systems nominal, ${sir()}. Thank you for asking.` })],
  [/^(?:are you there|are you awake|you there|can you hear me)$/, () => ({ say: `For you, ${sir()}, always.` })],
  [/^(?:who are you|what are you|what'?s your name|what is your name)$/, () => ({ say: 'I’m Jarvis, which stands for Just A Rather Very Intelligent System. I live in your browser: I can open websites, run timers, keep notes, and operate a small virtual workstation.' })],
  [/^(?:help|what can you do|what do you do|what are your commands|show commands|commands)$/, () => ({ say: 'I can open websites, search, check the weather, set timers, take notes, manage tasks, and run a virtual workstation. I’ve put some examples in the log.', display: HELP_TEXT })],
  [/^(?:tell me a joke|joke|make me laugh|say something funny)$/, () => ({ say: pick(JOKES) })],
  [/^(?:flip a coin|toss a coin|heads or tails)$/, () => ({ say: `It’s ${Math.random() < .5 ? 'heads' : 'tails'}.` })],
  [/^(?:roll (?:a |the )?(?:die|dice))$/, () => ({ say: `You rolled a ${1 + Math.floor(Math.random() * 6)}.` })],
  [/^(?:pick|choose|give me)(?: a)?(?: random)? number (?:between|from) (\d+) (?:and|to) (\d+)$/, m => { const a = +m[1], b = +m[2], lo = Math.min(a, b), hi = Math.max(a, b); return { say: `${lo + Math.floor(Math.random() * (hi - lo + 1))}.` }; }],
  [/^(?:do a barrel roll)$/, () => { document.body.animate([{ transform: 'rotate(0)' }, { transform: 'rotate(360deg)' }], { duration: 1200, easing: 'ease-in-out' }); return { say: 'Wheee. Not my best work, but I’ll take it.' }; }],
  [/^(?:suit up|iron man mode|activate (?:the )?(?:suit|armou?r))$/, () => { setTheme('red'); return { say: `Suit up, ${sir()}. Switching to combat colours.` }; }],
  [/^(?:switch to|set|change to|change the theme to|use|go)\s*(?:the )?(blue|red|gold|green|cyan)\s*(?:mode|theme|colou?rs?)$/, m => { const t = m[1] === 'cyan' ? 'blue' : m[1]; setTheme(t); return { say: `${cap(t)} it is.` }; }],
  [/^(?:back to normal|default (?:theme|colou?rs?)|normal mode)$/, () => { setTheme('blue'); return { say: 'Back to standard colours.' }; }],

  // ---- time & date
  [/^(?:what time is it|what'?s the time|what is the time|tell me the time|the time|time|current time)(?: now| right now)?$/, () => ({ say: `It’s ${new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}.` })],
  [/^(?:what(?:'s| is)? (?:the |today'?s )?date|what day is it|what'?s today|what is today|today'?s date|the date|date)(?: today)?$/, () => ({ say: `Today is ${new Date().toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })}.` })],

  // ---- timers & reminders
  [/^(?:cancel|stop|clear|delete) (?:all |my |the )*timers?$/, () => { const n = timers.length; timers = []; store.set('timers', timers); renderTimers(); return { say: n ? 'All timers cancelled.' : 'There are no timers running.' }; }],
  [/^(?:how much time is left|timer status|how long is left|check (?:the |my )?timers?|how long (?:is|on) (?:the |my )?timer)$/, () => timers.length ? { say: timers.map(t => `${fmtDur(Math.ceil((t.end - Date.now()) / 1000))} left${t.label ? ' to ' + t.label : ''}`).join('. ') + '.' } : { say: 'There are no timers running.' }],
  [/^remind me to (.+?) (?:in|after) (.+)$/, m => timerFrom(m[2], m[1])],
  [/^(?:remind|wake|alert|tell) me (?:in|after) (.+?)(?: (?:to|that|about) (.+))?$/, m => timerFrom(m[1], m[2])],
  [/^(?:set|start|create|make)(?: a| an)? (?:timer|alarm)(?: for)? (.+)$/, m => timerFrom(m[1])],
  [/^(?:set|start|create|make)(?: a| an)? (.+?) (?:timer|alarm)$/, m => timerFrom(m[1])],
  [/^timer(?: for)? (.+)$/, m => timerFrom(m[1])],

  // ---- weather
  [/\b(?:weather|forecast|temperature|how (?:hot|cold|warm) is it|is it (?:raining|snowing|cold|hot))\b/, async (m, t) => {
    if (/^(?:open|launch|go to|goto|take me to|visit|pull up|bring up|navigate to|load)\b/.test(t)) return null;   // “open the weather channel”
    const pm = t.match(/\b(?:in|for|at|near)\s+([a-z .,'-]+?)(?:\s+(?:today|tonight|tomorrow|right now|now|this week|this weekend))?$/);
    try { return { say: await weatherCmd(pm ? pm[1] : '') }; }
    catch (e) { return { say: e.user ? e.message : 'I couldn’t get the weather right now.' }; }
  }],

  // ---- notes & tasks
  [/^(?:read|show|what are|what'?s in)(?: me)?(?: my| the)? notes$/, () => {
    const lines = (fs['/home/jarvis/notes.txt']?.c || '').trim().split('\n').filter(Boolean);
    if (!lines.length) return { say: 'Your notes are empty.' };
    const last = lines.slice(-3).map(l => l.replace(/^\[[^\]]*\]\s*/, ''));
    return { say: `You have ${lines.length} note${lines.length > 1 ? 's' : ''}. The latest ${last.length > 1 ? 'are' : 'is'}: ${last.join('. ')}.`, display: lines.slice(-8).join('\n') };
  }],
  [/^(?:clear|delete|erase) (?:all )?(?:my )?notes$/, () => { fsWrite('/home/jarvis/notes.txt', ''); winEls.files?.api?.reload(); return { say: 'Notes cleared.' }; }],
  [/^(?:take|make|add|write|save|jot down|create)(?: me)?(?: a| another)? note(?: that| to self| saying)?[:,]?\s*(.+)$/, m => { addNote(m[1]); return { say: 'Noted.' }; }],
  [/^(?:note|remember|jot down|write down)(?: that| to)?[:,]?\s+(.+)$/, m => { addNote(m[1]); return { say: 'Noted.' }; }],
  [new RegExp(`^(?:add|put) (.+?) (?:to|on|onto) (?:my |the )?${TASK_WORDS}$`), m => { addTask(m[1]); return { say: `Added “${m[1]}” to your list.` }; }],
  [new RegExp(`^(?:add|create|new)(?: a)? (?:task|to[ -]?do|todo)(?: to)?[:,]?\\s*(.+)$`), m => { addTask(m[1]); return { say: `Added “${m[1]}” to your list.` }; }],
  [new RegExp(`^(?:what(?:'s| is) on |read |show |list |open )?(?:me )?(?:my |the )?${TASK_WORDS}$`), () => {
    const open = tasks.filter(t => !t.done);
    if (!open.length) return { say: 'Your list is clear.' };
    return { say: `You have ${open.length} task${open.length > 1 ? 's' : ''}: ${open.map(t => t.text).join(', ')}.` };
  }],
  [/^(?:complete|finish|check off|tick off|mark|done with)\s+(?:task\s+)?(?:number\s+)?(\S+?)(?:\s+(?:as )?(?:done|complete|completed))?$/, m => {
    const n = parseInt(wordsToDigits(m[1]), 10);
    if (!n) return null;
    const t = tasks[n - 1]; if (!t) return { say: `I don’t see a task number ${n}.` };
    t.done = true; saveTasks(); return { say: `Marked “${t.text}” as done.` };
  }],
  [new RegExp(`^(?:clear|delete|remove) (?:all |the )?(?:completed|finished|done) ${TASK_WORDS}$`), () => { tasks = tasks.filter(t => !t.done); saveTasks(); return { say: 'Completed tasks cleared.' }; }],
  [new RegExp(`^(?:clear|delete) (?:all )?(?:my )?${TASK_WORDS}$`), () => { tasks = []; saveTasks(); return { say: 'Task list cleared.' }; }],

  // ---- windows & interface
  [new RegExp(`^${WIN_VERB} (?:the |my )?(?:jarvis )?(?:workstation|work station|computer|terminal|console|command line|shell)$`), () => { openApp('terminal'); return { say: 'Workstation online.' }; }],
  [new RegExp(`^${WIN_VERB} (?:the |my )?(?:files|file manager|file browser|editor|text editor|documents)$`), () => { openApp('files'); return { say: 'Opening your files.' }; }],
  [new RegExp(`^${WIN_VERB} (?:the |my )?notes$`), () => { openApp('files', '/home/jarvis/notes.txt'); return { say: 'Here are your notes.' }; }],
  [new RegExp(`^${WIN_VERB} (?:the |my )?(?:system )?(?:monitor|diagnostics)$`), () => { openApp('monitor'); return { say: 'System monitor is up.' }; }],
  [/^(?:open|show) (?:the |my )?settings$/, () => { $('#settings').showModal(); return { say: 'Here are the settings.' }; }],
  [/^(?:close|dismiss|hide) (?:all |the |every )?(?:windows?|apps?|everything)$/, () => { closeAllWins(); return { say: 'Closed.' }; }],
  [/^clear (?:the |my )?(?:log|screen|chat|history|conversation)$/, () => { el.log.innerHTML = ''; return { silent: true }; }],
  [/^(?:run|execute|type)\s+(?:a |the )?(?:system )?diagnostics?$/, () => statusReport()],
  [/^(?:system|status|diagnostic)s?(?: report| status| check)?$|^(?:give me a )?status report$|^how are the systems$/, () => statusReport()],
  [/^(?:run|execute|type)\s+(.+)$/, async m => {
    const r = await runInTerminal(m[1]);
    const text = r && r.err ? r.err : (typeof r === 'string' ? r : '');
    return { say: text && text.length < 140 && !text.includes('\n') ? text : 'Done. The output is in the terminal.' };
  }],

  // ---- maps
  [/^(?:directions|navigate|route|how do i get|take me) to (.+)$/, m => { const r = openUrl('https://www.google.com/maps/dir/?api=1&destination=' + encodeURIComponent(m[1]), 'Directions: ' + m[1]); return { say: r.ok ? `Pulling up directions to ${m[1]}.` : BLOCKED('the map'), links: [r.link] }; }],
  [/^(?:find|show me|look up|search for|where(?:'s| is) (?:the )?(?:nearest|closest))\s+(.+?)\s*(?:near me|nearby|around here)$/, m => doSearch(m[1] + ' near me', 'maps')],
  [/^(?:where is|map of|show me (?:a )?map of)\s+(.+)$/, m => doSearch(m[1], 'maps')],

  // ---- search & play
  [/^(?:search|google|look up|lookup|find|search for|look for)\s+(?:for\s+)?(.+?)\s+(?:on|in|at|using|with)\s+(youtube|google maps|google|wikipedia|amazon|maps|reddit|github|ebay|twitter|x|spotify|imdb|bing|duckduckgo)$/, m => doSearch(m[1], m[2])],
  [/^(?:search|google|look up|lookup|search for|look for)\s+(?:for\s+)?(.+)$/, m => doSearch(m[1])],
  [/^(?:play|watch|put on)\s+(.+?)\s+on\s+(youtube|spotify)$/, m => doSearch(m[1], m[2])],
  [/^(?:play|watch)\s+(.+)$/, m => doSearch(m[1], 'youtube')],
  [/^(youtube|wikipedia|amazon|reddit|github|ebay|imdb)\s+(?!dot\b)(?!\.)(.+)$/, m => doSearch(m[2], m[1])],

  // ---- open websites (keep after the window intents)
  [/^(?:open|launch|go to|goto|take me to|pull up|bring up|visit|navigate to|load)\s+(.+)$/, m => openSiteByName(m[1])]
];

function timerFrom(dur, label) {
  const s = parseDuration(dur);
  if (!s) return { say: 'I didn’t catch how long. Try “set a timer for 5 minutes”.' };
  return addTimer(s, label ? label.trim() : '');
}

async function statusReport() {
  const s = await sysInfo();
  const bits = ['All systems nominal.'];
  if (s.batt != null) bits.push(`Battery at ${s.batt} percent${s.charging ? ' and charging' : ''}.`);
  if (s.cores) bits.push(`${s.cores} processor thread${s.cores > 1 ? 's' : ''} available.`);
  bits.push(s.online ? 'Network is online.' : 'Network appears to be offline.');
  bits.push(`Session uptime, ${fmtUptime()}.`);
  return { say: bits.join(' ') };
}

function normalize(text) {
  return text.toLowerCase().replace(/[’]/g, "'").replace(/[!?.,]+$/, '').replace(/\s+/g, ' ').trim()
    .replace(/^(?:(?:hey|ok|okay|yo|please|kindly|can you|could you|would you|will you|i want you to|i need you to|i'd like you to|go ahead and|just)\s+)+/, '')
    .replace(/\s+(?:please|for me|thanks|thank you)$/, '').trim();
}

async function route(raw, meta) {
  const t = normalize(raw);
  // Your own commands (Commands page) win over the built-in ones.
  if (typeof matchCustom === 'function') {
    const hit = matchCustom(t);
    if (hit) return runCustom(hit.cmd, hit.input, meta);
  }
  for (const [re, fn] of INTENTS) {
    const m = t.match(re);
    if (m) { const r = await fn(m, t, raw, meta); if (r) { Brain.emit('skills', `Skill: “${t.slice(0, 60)}”`); return r; } }
  }
  const math = tryMath(t);
  if (math) { Brain.emit('skills', `Calculated: ${t.slice(0, 50)}`); return math; }
  Brain.emit('reasoning', `No built-in skill for “${t.slice(0, 50)}”`, .8);
  return fallback(t, raw, meta);
}

let keyHintShown = false;
async function fallback(t, raw, meta) {
  const words = t.split(/\s+/).length;
  const spoken = !meta.viaWake && !meta.typed;       // a follow-up heard without the wake word
  if (aiReady()) {
    if (spoken && words < 3) return { silent: true };
    const { clean, links } = applyTags(await askClaude(raw));
    return { say: clean || 'Done.', links };
  }
  if (spoken) return { silent: true };
  if (/^(?:who|what|when|where|why|how|is|are|do|does|did|can|which|whose)\b/.test(t)) {
    const r = doSearch(raw);
    const hint = keyHintShown ? '' : ' Give me an AI key (see secrets.txt or Settings) and I can answer questions like that directly.';
    keyHintShown = true;
    return { say: (r.links[0] && r.say.startsWith('Searching') ? 'I’ll look that up for you.' : r.say) + hint, links: r.links };
  }
  return { say: `I’m not sure how to do that yet, ${sir()}. Say “help” to hear what I can do.` };
}

async function respond(r) {
  const { say, links = [], display, after } = typeof r === 'string' ? { say: r } : r;
  log('jarvis', display || say, links);
  await speak(say);
  if (micOn) extendAwake(7000);
  if (after) after();
}

async function handleCommand(text, meta = {}) {
  text = text.trim(); if (!text) return;
  // A follow-up heard without the wake word might just be background chatter,
  // so only show it once we know Jarvis is going to act on it.
  const maybeChatter = meta.viaWake === false;
  let shown = false;
  const showUser = () => { if (!shown) { shown = true; log('user', text); Brain.bump('commands'); Brain.emit('reasoning', `Command: “${text.slice(0, 70)}”`, .7); } };
  meta.show = showUser;
  if (!maybeChatter) showUser();
  busy = true; setState('thinking');
  let r;
  try { r = await route(text, meta); }
  catch (err) { console.error(err); r = { say: `I ran into a problem: ${err.message || 'unknown error'}` }; }
  busy = false;
  if (r && r.silent) { rest(); return; }
  showUser();
  await respond(r);
}


/* ---------------------------------------------------------------------
   7. Optional AI brain (Anthropic API, called straight from the browser)
   --------------------------------------------------------------------- */
const convo = [];

// One place that talks to the language model. Uses the local core (key stays on the server)
// when it has a key, otherwise calls Anthropic straight from the browser with your own key.
async function callAI(system, messages, maxTokens = 400) {
  const t0 = performance.now();
  Brain.emit('reasoning', 'Consulting the language model…', 1.3);
  let res;
  try {
    if (core.online && core.hasKey) {
      const body = { system, messages, max_tokens: maxTokens };
      if (settings.model && settings.model !== DEFAULTS.model) body.model = settings.model;
      res = await corePost('/api/chat', body);
    } else {
      res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          'x-api-key': settings.apiKey,
          'anthropic-version': '2023-06-01',
          'anthropic-dangerous-direct-browser-access': 'true'
        },
        body: JSON.stringify({ model: settings.model || DEFAULTS.model, max_tokens: maxTokens, system, messages })
      });
    }
  } catch { throw userErr('I couldn’t reach the AI service. Check your connection.'); }
  if (!res.ok) {
    if (res.status === 401) throw userErr('The AI service rejected the API key. Check it.');
    if (res.status === 404) throw userErr('The AI service doesn’t recognise the model name.');
    if (res.status === 429) throw userErr('The AI service is rate limiting me. Try again in a moment.');
    if (res.status === 400 && core.online && core.hasKey) throw userErr('The AI request was refused. Check the model name in secrets.txt.');
    throw userErr(`The AI service returned error ${res.status}.`);
  }
  const data = await res.json();
  const out = (data.content || []).filter(b => b.type === 'text').map(b => b.text).join(' ').trim();
  Brain.setVital('aiTime', ((performance.now() - t0) / 1000).toFixed(1) + ' s');
  return out;
}

async function askClaude(text) {
  const system = `You are J.A.R.V.I.S., a calm, dry-witted, British-sounding AI assistant running inside the user's web browser. Address the user as "${sir()}". Your replies are spoken aloud: keep them to one to three short sentences, in plain text with no markdown, lists or emojis. The current date and time is ${new Date().toString()}.
You can trigger actions by adding tags at the very end of a reply. Tags are never spoken.
[[open:https://example.com]] opens a website
[[search:query]] runs a Google search
[[note:text]] saves a note
[[task:text]] adds a to-do item
[[timer:SECONDS|label]] starts a timer (label optional)
[[run:command]] runs a command in the user's virtual workstation terminal
[[page:name]] switches the interface to one of: home, brain, commands, computer
[[theme:name]] changes colours to one of: blue, red, gold, green
${core.online ? '[[launch:program]] launches a program on the user\'s computer. Available: ' + (Object.keys(core.apps).join(', ') || 'none') : ''}
Only use a tag when the user asked for that action. You cannot see the screen or control anything that isn't listed above; if asked, say so briefly.`;
  convo.push({ role: 'user', content: text });
  while (convo.length > 12 || (convo.length && convo[0].role !== 'user')) convo.shift();
  let out;
  try { out = await callAI(system, convo, 400); } catch (e) { convo.pop(); throw e; }
  convo.push({ role: 'assistant', content: out || '(no reply)' });
  return out;
}

function applyTags(text) {
  const links = [];
  const clean = text.replace(/\[\[(\w+):([^\]]*)\]\]/g, (_, k, v) => {
    v = v.trim();
    try {
      if (k === 'open' && /^https?:\/\//i.test(v)) links.push(openUrl(v).link);
      else if (k === 'search') links.push(doSearch(v).links[0]);
      else if (k === 'note') addNote(v);
      else if (k === 'task') addTask(v);
      else if (k === 'timer') { const [s, label] = v.split('|'); const secs = parseInt(s, 10); if (secs > 0) addTimer(secs, (label || '').trim()); }
      else if (k === 'run') runInTerminal(v);
      else if (k === 'launch' && window.launchApp) window.launchApp(v);
      else if (k === 'page' && window.showPage) window.showPage(v);
      else if (k === 'theme' && ['blue', 'red', 'gold', 'green'].includes(v)) setTheme(v);
    } catch (e) { console.warn('Tag failed', k, e); }
    return '';
  }).replace(/\s+/g, ' ').trim();
  return { clean, links };
}


/* ---------------------------------------------------------------------
   8. Start-up
   --------------------------------------------------------------------- */
// Buttons & inputs
el.micBtn.addEventListener('click', () => {
  if (!SR) { log('jarvis', 'Voice input needs Chrome, Edge or Safari. You can still type commands below.'); return; }
  micOn ? stopMic() : startMic();
});
$('#btnComputer').addEventListener('click', () => openApp('terminal'));
$('#btnSettings').addEventListener('click', () => { fillSettings(); $('#settings').showModal(); });
el.cmdForm.addEventListener('submit', e => {
  e.preventDefault();
  const v = el.cmdInput.value; el.cmdInput.value = '';
  audio(); handleCommand(v.replace(wakeRe(), '').replace(/^[\s,.:;!?-]+/, '') || v, { typed: true });
});

// AI status shown on the Brain page and in Settings
function updateAiVital() {
  Brain.setVital('ai', core.hasKey ? 'Connected (key on local core)' : settings.apiKey ? 'Connected (browser key)' : 'Offline: built-in skills only');
  const st = $('#sAiStatus');
  if (st) st.textContent = core.hasKey
    ? 'The local core already has your API key from secrets.txt, so there is nothing to enter here.'
    : core.online
      ? 'The local core is running but has no key yet. Paste one after ANTHROPIC_API_KEY= in secrets.txt and restart Jarvis, or use the browser key below.'
      : 'Running without the local core. Paste a key below, or start Jarvis with start.command or start-windows.bat and put the key in secrets.txt instead.';
}

// Settings dialog
const dlg = $('#settings');
function fillSettings() {
  loadVoices();
  $('#sWake').value = settings.wake; $('#sAddress').value = settings.address;
  $('#sUnits').value = settings.units; $('#sCity').value = settings.city;
  $('#sRate').value = settings.rate; $('#sPitch').value = settings.pitch;
  $('#sAck').checked = settings.ackVoice; $('#sOrb').checked = settings.orbMic;
  $('#sKey').value = settings.apiKey; $('#sModel').value = settings.model;
  $('#sCoreOpen').checked = settings.coreOpen; updateAiVital();
  $('#sVoice').value = settings.voice || '';
  $('#sMsg').textContent = '';
}
$('#settingsForm').addEventListener('submit', () => {
  const cityChanged = $('#sCity').value.trim() !== settings.city;
  Object.assign(settings, {
    wake: ($('#sWake').value.trim().toLowerCase() || 'jarvis'), address: $('#sAddress').value.trim() || 'sir',
    units: $('#sUnits').value, city: $('#sCity').value.trim(), voice: $('#sVoice').value,
    rate: +$('#sRate').value, pitch: +$('#sPitch').value, ackVoice: $('#sAck').checked, orbMic: $('#sOrb').checked,
    apiKey: $('#sKey').value.trim(), model: $('#sModel').value.trim() || DEFAULTS.model, coreOpen: $('#sCoreOpen').checked
  });
  if (cityChanged) settings.coords = null;
  saveSettings();
  if (settings.orbMic && micOn) startMeter(); else if (!settings.orbMic) stopMeter();
  updateAiVital(); syncMicBtn();
  rest();
  if (settings.city) weatherCmd('').catch(() => { });
});
$('#sCancel').addEventListener('click', () => dlg.close());
$('#sTestVoice').addEventListener('click', () => {
  const keep = { ...settings };
  Object.assign(settings, { voice: $('#sVoice').value, rate: +$('#sRate').value, pitch: +$('#sPitch').value });
  speak(`${greetWord()}, ${$('#sAddress').value || 'sir'}. This is how I sound.`).then(() => Object.assign(settings, { voice: keep.voice, rate: keep.rate, pitch: keep.pitch }));
});
$('#sTestPopup').addEventListener('click', () => {
  const msg = $('#sMsg');
  if (core.online && settings.coreOpen) { msg.textContent = 'Not needed: the local core opens links in your default browser for me.'; return; }
  msg.textContent = 'Testing… a blank tab will try to open in 7 seconds, without a click, the way a voice command would.';
  setTimeout(() => {
    let w = null; try { w = window.open('about:blank', '_blank'); } catch { /* blocked */ }
    if (w) { try { w.close(); } catch { /* ignore */ } msg.textContent = 'Pop-ups are allowed. I can open sites by voice.'; }
    else msg.textContent = 'Blocked. Click the pop-up icon in the address bar, choose “Always allow pop-ups”, and test again.';
  }, 7000);
});

// Keyboard: Escape closes the top window
document.addEventListener('keydown', e => {
  if (e.key === 'Escape' && !dlg.open) {
    const ids = Object.keys(winEls);
    if (ids.length) closeWin(ids.sort((a, b) => (+winEls[b].el.style.zIndex) - (+winEls[a].el.style.zIndex))[0]);
  }
});

// Clock, timers, device panel
function tickClock() {
  const d = new Date();
  el.clock.textContent = d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  el.date.textContent = d.toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric' });
}
setInterval(() => { tickClock(); tickTimers(); }, 1000);
setInterval(renderSys, 10000);

// Boot screen
(function boot() {
  const lines = [
    ['Loading voice core', ''],
    [`Calibrating wake word “${cap(settings.wake)}”`, ''],
    ['Mounting virtual workstation', ''],
    ['Rendering neural map', ''],
    [SR ? 'Speech recognition ready' : 'Speech recognition unavailable in this browser', SR ? '' : 'warn'],
    ['Standing by', '']
  ];
  const ul = $('#bootLines');
  lines.forEach(([t, cls], i) => {
    const li = document.createElement('li');
    li.textContent = t; if (cls) li.className = cls; li.style.animationDelay = (i * 0.35) + 's';
    ul.appendChild(li);
  });
  const note = $('#bootNote');
  if (location.protocol === 'file:') note.textContent = 'Opened straight from a file: Chrome will keep asking for the microphone. For the best experience, launch with start.command (Mac/Linux) or start-windows.bat (Windows).';
  else if (!window.isSecureContext) note.textContent = 'This page isn’t on a secure address, so the browser will block the microphone. Use http://localhost or https.';
  else if (!SR) note.textContent = 'Voice input works in Chrome, Edge and Safari. You can still type commands.';
})();

$('#initBtn').addEventListener('click', async () => {
  $('#boot').classList.add('done');
  audio(); chime();
  setTheme(store.get('theme', 'blue'));
  loadVoices();
  renderTasks(); renderTimers(); renderSys(); tickClock();
  requestAnimationFrame(orbLoop);
  if (settings.city || settings.coords) weatherCmd('').catch(() => { });

  log('jarvis', `Say “${cap(settings.wake)}” followed by a command, or type below. Say “help” for ideas.`);
  if (SR) { await startMeter(); startMic(); } else setState('off');
  const hello = `${greetWord()}, ${sir()}. All systems are online.` + (SR ? ` Say my name whenever you need me.` : ' Voice input isn’t supported here, but you can type commands.');
  respond({ say: hello });
});

setTheme(store.get('theme', 'blue'));
