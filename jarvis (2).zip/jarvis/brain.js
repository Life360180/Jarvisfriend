'use strict';

/* =====================================================================
   J.A.R.V.I.S. — the Brain page.

   A stylised 3D map of Jarvis's subsystems, drawn on a plain <canvas>
   with our own projection maths (no libraries, works offline).

   It is a visualisation of what Jarvis is doing, not a scan of the
   language model's real network. Each region lights up when the matching
   part of Jarvis runs: hearing, language, reasoning, skills, memory,
   the web, and reflexes.

   app.js calls Brain.emit('web', 'Opened YouTube') and so on.
   ===================================================================== */
const Brain = (() => {
  const REGIONS = [
    { key: 'reasoning', name: 'Prefrontal cortex', role: 'Reasoning', hue: 0,
      desc: 'Works out what you meant and picks the skill that should handle it. When nothing built in fits, it hands the request to the language model.',
      tryIt: ['What’s 15 percent of 240?', 'Who wrote Hamlet?'] },
    { key: 'language', name: 'Language centre', role: 'Speech', hue: 48,
      desc: 'Turns replies into spoken words and applies the voice, speed and pitch you chose.',
      tryIt: ['Tell me a joke', 'Speak slower'] },
    { key: 'hearing', name: 'Auditory cortex', role: 'Hearing', hue: -52,
      desc: 'Listens for the wake word and turns your speech into text. It pauses while Jarvis talks so he doesn’t hear himself.',
      tryIt: ['Are you there?', 'Can you hear me?'] },
    { key: 'skills', name: 'Motor cortex', role: 'Skills', hue: 104,
      desc: 'Carries out actions: the built-in skills and every custom command you define on the Commands page.',
      tryIt: ['Set a timer for 1 minute', 'Roll a die'] },
    { key: 'memory', name: 'Hippocampus', role: 'Memory', hue: -112,
      desc: 'Holds your notes, tasks, custom commands and the running conversation, all stored in this browser.',
      tryIt: ['Take a note: the brain page is cool', 'What’s on my list?'] },
    { key: 'web', name: 'Visual cortex', role: 'The web', hue: 168,
      desc: 'Reaches outside: opens sites, runs searches and fetches the weather.',
      tryIt: ['Open Wikipedia', 'What’s the weather?'] },
    { key: 'reflex', name: 'Cerebellum', role: 'Reflexes', hue: 214,
      desc: 'Fast, automatic work: timers, the clock and system checks.',
      tryIt: ['What time is it?', 'System status'] }
  ];
  const KEY_INDEX = Object.fromEntries(REGIONS.map((r, i) => [r.key, i]));

  /* ---------- state ---------- */
  let nodes = [], edges = [], byRegion = [], centers = [], built = false;
  const act = new Float32Array(REGIONS.length);       // 0..1 glow per region
  const floor = new Float32Array(REGIONS.length);     // baseline glow for the current mode
  const counts = REGIONS.map(() => 0);
  const lastText = REGIONS.map(() => '');
  const thoughts = [];
  const vitals = { ai: 'Checking…', aiTime: '—', commands: 0, voice: 'Off' };
  let pulses = [];
  let tints = REGIONS.map(() => '#4de8ff');
  let accent = '#4de8ff';
  let mode = 'idle';

  // view
  let yaw = 0.5, pitch = 0.2, zoom = 1, tween = null, vel = 0;
  let selected = -1, hover = -1;
  let showSyn = true, showLabels = true, autoRotate = !matchMedia('(prefers-reduced-motion: reduce)').matches;
  let visible = false, raf = 0, last = 0, frame = 0, ambientAt = 0;

  // dom
  let cv, ctx, W = 0, H = 0, dpr = 1, mounted = false;
  const q = id => document.getElementById(id);
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  /* ---------- building the brain ---------- */
  function rng(seed) {
    return () => { seed |= 0; seed = seed + 0x6D2B79F5 | 0; let t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };
  }

  function build() {
    if (built) return;
    built = true;
    const rnd = rng(11);
    const MIN_D = 0.062;
    const tooClose = (x, y, z) => {
      for (let i = 0; i < nodes.length; i++) {
        const n = nodes[i], dx = n.x - x, dy = n.y - y, dz = n.z - z;
        if (dx * dx + dy * dy + dz * dz < MIN_D * MIN_D) return true;
      }
      return false;
    };
    const push = (x, y, z, g) => { nodes.push({ x, y, z, g, r: 0, nb: [], sx: 0, sy: 0, d: 0 }); };

    // two hemispheres with folded surfaces
    for (const s of [-1, 1]) {
      let made = 0, tries = 0;
      while (made < 430 && tries++ < 20000) {
        const u = rnd() * 2 - 1, th = rnd() * Math.PI * 2, r2 = Math.sqrt(1 - u * u);
        const dx = r2 * Math.cos(th), dy = u, dz = r2 * Math.sin(th);
        const inner = rnd() < 0.2 ? 0.35 + rnd() * 0.5 : 1;
        const a = Math.atan2(dz, dx), b = Math.asin(dy);
        const fold = 1 + 0.06 * Math.sin(9 * a + 3 * b) * Math.cos(7 * b) + 0.04 * Math.sin(15 * a - 4 * b);
        let z = dz * 1.06 * inner * fold;
        const taper = z > 0.45 ? 1 - (z - 0.45) * 0.34 : z < -0.6 ? 1 - (-0.6 - z) * 0.42 : 1;
        let x = dx * 0.47 * inner * fold * taper;
        let y = dy * 0.7 * inner * fold;
        if (y < 0) y *= 0.7;
        if (dy < -0.15 && Math.abs(z) < 0.55) x *= 1.12;              // temporal bulge
        x = s * (0.02 + Math.abs(x + 0.44 * taper));
        y += 0.05;
        if (!tooClose(x, y, z)) { push(x, y, z, 'cortex'); made++; }
      }
    }
    // cerebellum: small ridged lobe at the back, underneath
    for (let made = 0, tries = 0; made < 120 && tries++ < 8000;) {
      const u = rnd() * 2 - 1, th = rnd() * Math.PI * 2, r2 = Math.sqrt(1 - u * u), k = rnd() < 0.15 ? 0.6 : 1;
      const x = r2 * Math.cos(th) * 0.5 * k, y = -0.5 + u * 0.2 * k + 0.018 * Math.sin(u * 22), z = -0.8 + r2 * Math.sin(th) * 0.3 * k;
      if (!tooClose(x, y, z)) { push(x, y, z, 'cb'); made++; }
    }
    // brain stem
    for (let i = 0; i < 34; i++) {
      const t = i / 33, a = rnd() * Math.PI * 2, rad = 0.085 * (1 - t * 0.3);
      push(Math.cos(a) * rad, -0.3 - t * 0.7, -0.3 - t * 0.2 + Math.sin(a) * rad, 'st');
    }

    // regions by position
    for (const n of nodes) {
      const { x, y, z } = n, ax = Math.abs(x);
      let r;
      if (n.g === 'cb' || n.g === 'st') r = 'reflex';
      else if (z > 0.5 && y > 0.0) r = 'reasoning';
      else if (z > 0.22) r = 'language';
      else if (z < -0.5) r = 'web';
      else if (ax > 0.32 && y < 0.12) r = 'hearing';
      else if (ax < 0.36 && y < 0.36 && y > -0.32) r = 'memory';
      else r = 'skills';
      n.r = KEY_INDEX[r];
    }
    byRegion = REGIONS.map(() => []);
    nodes.forEach((n, i) => byRegion[n.r].push(i));
    centers = byRegion.map(list => {
      const c = { x: 0, y: 0, z: 0 };
      list.forEach(i => { c.x += nodes[i].x; c.y += nodes[i].y; c.z += nodes[i].z; });
      const k = Math.max(1, list.length); c.x /= k; c.y /= k; c.z /= k; return c;
    });

    // synapses: each neuron links to its 3 nearest neighbours
    const seen = new Set();
    for (let i = 0; i < nodes.length; i++) {
      const cand = [];
      for (let j = 0; j < nodes.length; j++) {
        if (i === j) continue;
        const dx = nodes[i].x - nodes[j].x, dy = nodes[i].y - nodes[j].y, dz = nodes[i].z - nodes[j].z;
        const d = dx * dx + dy * dy + dz * dz;
        if (d < 0.19 * 0.19 * 1.9) cand.push([d, j]);
      }
      cand.sort((a, b) => a[0] - b[0]);
      for (const [, j] of cand.slice(0, 3)) {
        const key = i < j ? i * 4096 + j : j * 4096 + i;
        if (seen.has(key)) continue;
        seen.add(key);
        edges.push({ a: i, b: j, r: nodes[i].r });
        nodes[i].nb.push(j); nodes[j].nb.push(i);
      }
    }
  }

  /* ---------- colour ---------- */
  function refreshColors() {
    let c = '';
    try { c = getComputedStyle(document.body).getPropertyValue('--cyan').trim(); } catch { /* ignore */ }
    const m = c.match(/^#([0-9a-f]{3}|[0-9a-f]{6})$/i);
    if (!m) return;
    accent = c;
    let h = m[1]; if (h.length === 3) h = h.split('').map(x => x + x).join('');
    const r = parseInt(h.slice(0, 2), 16) / 255, g = parseInt(h.slice(2, 4), 16) / 255, b = parseInt(h.slice(4, 6), 16) / 255;
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn;
    let hue = 0;
    if (d) hue = mx === r ? ((g - b) / d) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4;
    hue = (hue * 60 + 360) % 360;
    tints = REGIONS.map(R => `hsl(${(hue + R.hue + 360) % 360} 92% 62%)`);
    renderRegions(); renderDetail(); renderStream();
  }

  /* ---------- events from the rest of Jarvis ---------- */
  function spawn(ri, n, hops) {
    if (!built || !byRegion[ri] || !byRegion[ri].length) return;
    for (let k = 0; k < n && pulses.length < 420; k++) {
      const list = byRegion[ri], a = list[Math.floor(Math.random() * list.length)];
      const nb = nodes[a].nb; if (!nb.length) continue;
      pulses.push({ a, b: nb[Math.floor(Math.random() * nb.length)], t: Math.random() * 0.3, hops, r: ri });
    }
  }

  function emit(key, text, strength = 1) {
    build();
    const ri = KEY_INDEX[key]; if (ri == null) return;
    act[ri] = Math.min(1, act[ri] + 0.55 * strength);
    spawn(ri, Math.round(3 + strength * 5), 6);
    counts[ri]++;
    if (text) {
      lastText[ri] = text;
      thoughts.unshift({ t: Date.now(), ri, text });
      if (thoughts.length > 40) thoughts.pop();
      renderStream();
    }
    if (selected === ri) renderDetail();
    renderCounts();
  }

  function setMode(m) {
    mode = m;
    floor.fill(0);
    if (m === 'listening') floor[KEY_INDEX.hearing] = 0.4;
    if (m === 'thinking') { floor[KEY_INDEX.reasoning] = 0.6; floor[KEY_INDEX.skills] = 0.25; }
    if (m === 'speaking') floor[KEY_INDEX.language] = 0.55;
    if (m === 'standby') floor[KEY_INDEX.hearing] = 0.12;
  }

  function setVital(k, v) { vitals[k] = v; renderVitals(); }
  function bump(k) { vitals[k] = (vitals[k] || 0) + 1; renderVitals(); }

  /* ---------- side panels ---------- */
  function renderRegions() {
    const box = q('brRegions'); if (!box) return;
    box.innerHTML = REGIONS.map((R, i) =>
      `<button type="button" class="br-reg${i === selected ? ' on' : ''}" data-i="${i}" style="--tint:${tints[i]}"><i></i><span>${esc(R.role)}</span><b>${counts[i]}</b></button>`).join('');
  }
  function renderCounts() {
    const box = q('brRegions'); if (!box) return;
    box.querySelectorAll('.br-reg b').forEach((b, i) => { b.textContent = counts[i]; });
  }
  function renderDetail() {
    const box = q('brDetail'); if (!box) return;
    if (selected < 0) { box.innerHTML = '<p class="muted">Select a region to see what it does. Its example phrases run when clicked.</p>'; return; }
    const R = REGIONS[selected];
    box.innerHTML = `<h3 style="--tint:${tints[selected]}">${esc(R.name)}</h3>
      <p class="br-meta">${esc(R.role)} · ${counts[selected]} activation${counts[selected] === 1 ? '' : 's'}</p>
      <p>${esc(R.desc)}</p>
      <p class="br-last">${lastText[selected] ? 'Last signal: ' + esc(lastText[selected]) : 'No signals yet this session.'}</p>
      <div class="br-try">${R.tryIt.map(t => `<button type="button" class="chip-btn" data-try="${esc(t)}">${esc(t)}</button>`).join('')}</div>`;
  }
  function renderVitals() {
    const box = q('brVitals'); if (!box) return;
    box.innerHTML = `<dt>Neurons</dt><dd>${nodes.length}</dd><dt>Synapses</dt><dd>${edges.length}</dd>
      <dt>Language model</dt><dd>${esc(vitals.ai)}</dd><dt>Last AI reply</dt><dd>${esc(vitals.aiTime)}</dd>
      <dt>Commands run</dt><dd>${vitals.commands}</dd><dt>Microphone</dt><dd>${esc(vitals.voice)}</dd>`;
  }
  function renderStream() {
    const ul = q('brStream'); if (!ul) return;
    if (!thoughts.length) { ul.innerHTML = '<li class="muted">Quiet for now. Say something to Jarvis.</li>'; return; }
    ul.innerHTML = thoughts.slice(0, 24).map(t => {
      const time = new Date(t.t).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', second: '2-digit' });
      return `<li style="--tint:${tints[t.ri]}"><i></i><span class="tx">${esc(t.text)}</span><time>${time}</time></li>`;
    }).join('');
  }

  function select(i) {
    selected = (i === selected ? -1 : i);
    if (selected >= 0 && built) {
      const c = centers[selected];
      const ty = Math.atan2(-c.x, c.z || 0.001), tp = Math.max(-0.5, Math.min(0.7, 0.28 - c.y * 0.5));
      tween = { yaw: ty, pitch: tp };
    } else tween = null;
    renderRegions(); renderDetail();
  }

  /* ---------- rendering ---------- */
  function resize() {
    if (!cv) return;
    const r = cv.parentElement.getBoundingClientRect();
    dpr = Math.min(2, window.devicePixelRatio || 1);
    W = Math.max(200, Math.floor(r.width)); H = Math.max(200, Math.floor(r.height));
    cv.width = W * dpr; cv.height = H * dpr;
    cv.style.width = W + 'px'; cv.style.height = H + 'px';
  }

  const CAM = 3.3;
  let cyw = 1, syw = 0, cpt = 1, spt = 0, px = 100;
  function proj(x, y, z, out) {
    const x1 = x * cyw + z * syw, z1 = -x * syw + z * cyw;
    const y2 = y * cpt - z1 * spt, z2 = y * spt + z1 * cpt;
    const k = CAM / (CAM - z2);
    out[0] = W / 2 + x1 * k * px; out[1] = H * 0.5 - (y2 - 0.04) * k * px; out[2] = z2;
    return out;
  }
  const tmp = [0, 0, 0], tmp2 = [0, 0, 0];

  function project() {
    cyw = Math.cos(yaw); syw = Math.sin(yaw); cpt = Math.cos(pitch); spt = Math.sin(pitch);
    px = Math.min(W * 0.42, H * 0.40) * zoom;
    for (const n of nodes) { proj(n.x, n.y, n.z, tmp); n.sx = tmp[0]; n.sy = tmp[1]; n.d = tmp[2]; }
  }

  function ring(radius, y, alpha, color) {
    ctx.beginPath();
    for (let i = 0; i <= 72; i++) {
      const a = i / 72 * Math.PI * 2; proj(Math.cos(a) * radius, y, Math.sin(a) * radius, tmp);
      i ? ctx.lineTo(tmp[0], tmp[1]) : ctx.moveTo(tmp[0], tmp[1]);
    }
    ctx.globalAlpha = alpha; ctx.strokeStyle = color; ctx.lineWidth = 1; ctx.stroke();
  }

  function draw(now) {
    const dt = Math.min(0.05, (now - last) / 1000 || 0.016); last = now; frame++;
    if (frame % 40 === 1) { try { const c = getComputedStyle(document.body).getPropertyValue('--cyan').trim(); if (c && c !== accent) refreshColors(); } catch { /* ignore */ } }

    // camera
    if (tween) {
      let dy = tween.yaw - yaw; dy = Math.atan2(Math.sin(dy), Math.cos(dy));
      yaw += dy * Math.min(1, dt * 5); pitch += (tween.pitch - pitch) * Math.min(1, dt * 5);
      if (Math.abs(dy) < 0.004 && Math.abs(tween.pitch - pitch) < 0.004) tween = null;
    } else if (Math.abs(vel) > 0.00005) { yaw += vel; vel *= 0.94; }
    else if (autoRotate && selected < 0 && !dragging) yaw += dt * 0.22;

    // activity decay + ambient chatter
    const decay = Math.pow(0.32, dt);
    let total = 0;
    for (let i = 0; i < act.length; i++) { act[i] = Math.max(floor[i], act[i] * decay); total += act[i]; }
    ambientAt -= dt;
    if (ambientAt <= 0) {
      ambientAt = mode === 'idle' ? 0.32 : 0.14;
      spawn(Math.floor(Math.random() * REGIONS.length), 1, 4);
    }
    // pulses hop along synapses
    for (let i = pulses.length - 1; i >= 0; i--) {
      const p = pulses[i]; p.t += dt * 3.6;
      if (p.t < 1) continue;
      act[nodes[p.b].r] = Math.min(1, act[nodes[p.b].r] + 0.012);
      if (--p.hops <= 0) { pulses.splice(i, 1); continue; }
      const nb = nodes[p.b].nb, from = p.a;
      let next = nb[Math.floor(Math.random() * nb.length)];
      if (next === from && nb.length > 1) next = nb[(nb.indexOf(next) + 1) % nb.length];
      p.a = p.b; p.b = next; p.t = 0;
    }

    project();
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, W, H);
    ctx.globalCompositeOperation = 'lighter';
    ctx.lineJoin = 'round';

    // hologram base
    const baseY = -0.98;
    ring(1.4, baseY, 0.16, accent); ring(1.1, baseY, 0.10, accent);
    ctx.globalAlpha = 0.09; ctx.strokeStyle = accent; ctx.beginPath();
    for (let i = 0; i < 24; i++) {
      const a = i / 24 * Math.PI * 2;
      proj(Math.cos(a) * 1.1, baseY, Math.sin(a) * 1.1, tmp); proj(Math.cos(a) * 1.4, baseY, Math.sin(a) * 1.4, tmp2);
      ctx.moveTo(tmp[0], tmp[1]); ctx.lineTo(tmp2[0], tmp2[1]);
    }
    ctx.stroke();
    // scan plane
    const scanY = -0.9 + ((now / 4200) % 1) * 1.7;
    ring(1.0, scanY, 0.30, accent);

    // synapses
    if (showSyn) {
      const R = REGIONS.length, paths = new Array(R * 4), glow = new Array(R);
      for (let i = 0; i < R * 4; i++) paths[i] = new Path2D();
      for (let i = 0; i < R; i++) glow[i] = act[i] > 0.03 ? new Path2D() : null;
      for (const e of edges) {
        const a = nodes[e.a], b = nodes[e.b];
        const t = Math.max(0, Math.min(0.999, ((a.d + b.d) / 2 + 1.2) / 2.4));
        const p = paths[e.r * 4 + Math.floor(t * 4)];
        p.moveTo(a.sx, a.sy); p.lineTo(b.sx, b.sy);
        if (glow[e.r]) { glow[e.r].moveTo(a.sx, a.sy); glow[e.r].lineTo(b.sx, b.sy); }
      }
      const BUCKET = [0.05, 0.09, 0.15, 0.26], dim = selected >= 0 ? 0.55 : 1;
      ctx.lineWidth = 1;
      for (let r = 0; r < R; r++) {
        ctx.strokeStyle = tints[r];
        const boost = r === selected ? 1.7 : r === hover ? 1.4 : dim;
        for (let b = 0; b < 4; b++) { ctx.globalAlpha = Math.min(0.6, BUCKET[b] * boost); ctx.stroke(paths[r * 4 + b]); }
        if (glow[r]) { ctx.globalAlpha = Math.min(0.85, act[r] * 0.7); ctx.lineWidth = 1.4; ctx.stroke(glow[r]); ctx.lineWidth = 1; }
      }
    }

    // neurons
    for (let r = 0; r < REGIONS.length; r++) {
      ctx.fillStyle = tints[r];
      const boost = r === selected ? 0.3 : r === hover ? 0.2 : 0, dim = selected >= 0 && r !== selected ? 0.6 : 1;
      const list = byRegion[r];
      for (let k = 0; k < list.length; k++) {
        const n = nodes[list[k]];
        const t = Math.max(0, Math.min(1, (n.d + 1.2) / 2.4));
        const scan = Math.max(0, 1 - Math.abs(n.y - scanY) / 0.07);
        const a = (0.22 + t * 0.6 + act[r] * 0.5 + boost + scan * 0.7) * dim;
        const s = (1.3 + t * 1.7 + act[r] * 1.4 + scan * 2) ;
        ctx.globalAlpha = Math.min(1, a);
        ctx.fillRect(n.sx - s / 2, n.sy - s / 2, s, s);
      }
    }

    // signal pulses
    for (const p of pulses) {
      const a = nodes[p.a], b = nodes[p.b];
      const x = a.sx + (b.sx - a.sx) * p.t, y = a.sy + (b.sy - a.sy) * p.t;
      ctx.fillStyle = tints[p.r];
      ctx.globalAlpha = 0.28; ctx.beginPath(); ctx.arc(x, y, 6.5, 0, 6.283); ctx.fill();
      ctx.globalAlpha = 0.95; ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(x, y, 1.9, 0, 6.283); ctx.fill();
    }

    // labels
    ctx.globalCompositeOperation = 'source-over';
    if (showLabels) {
      ctx.font = '600 14px Rajdhani, "Segoe UI", system-ui, sans-serif'; ctx.textBaseline = 'middle'; ctx.lineJoin = 'round';
      for (let r = 0; r < REGIONS.length; r++) {
        const c = centers[r]; proj(c.x, c.y, c.z, tmp);
        const front = (tmp[2] + 1.2) / 2.4, tw = ctx.measureText(REGIONS[r].role).width;
        let side = tmp[0] >= W / 2 ? 1 : -1;
        const reach = 34 + Math.abs(c.x) * 30 + 16 + tw;
        if (side > 0 && tmp[0] + reach > W - 8) side = -1; else if (side < 0 && tmp[0] - reach < 8) side = 1;
        const ex = tmp[0] + side * (34 + Math.abs(c.x) * 30), ey = tmp[1] - 18;
        const on = r === selected || r === hover, lit = Math.min(1, act[r] * 1.4);
        ctx.globalAlpha = Math.min(1, Math.max(0.5, front * 0.9 + 0.2) * (selected >= 0 && !on ? 0.55 : 1) + lit * 0.2);
        ctx.strokeStyle = tints[r]; ctx.fillStyle = tints[r]; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(tmp[0], tmp[1]); ctx.lineTo(ex, ey); ctx.lineTo(ex + side * 12, ey); ctx.stroke();
        ctx.beginPath(); ctx.arc(tmp[0], tmp[1], on ? 4 : 2.6, 0, 6.283); ctx.fill();
        ctx.textAlign = side > 0 ? 'left' : 'right';
        ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(2,9,14,.9)'; ctx.strokeText(REGIONS[r].role, ex + side * 16, ey);
        ctx.fillStyle = on || lit > 0.4 ? '#fff' : tints[r];
        ctx.fillText(REGIONS[r].role, ex + side * 16, ey);
      }
    }
    ctx.globalAlpha = 1;

    // panel bits that follow activity (throttled)
    if (frame % 8 === 0) {
      const box = q('brRegions');
      if (box) box.querySelectorAll('.br-reg').forEach((b, i) => b.style.setProperty('--act', act[i].toFixed(2)));
      const bar = q('brLoad'); if (bar) bar.style.width = Math.min(100, Math.round(total / REGIONS.length * 260)) + '%';
    }
  }

  function loop(now) {
    if (!visible) { raf = 0; return; }
    draw(now);
    raf = requestAnimationFrame(loop);
  }

  function setVisible(v) {
    visible = v;
    if (v) { build(); if (!mounted) mount(); resize(); renderRegions(); renderDetail(); renderVitals(); renderStream(); refreshColors(); if (!raf) { last = performance.now(); raf = requestAnimationFrame(loop); } }
  }

  /* ---------- pointer controls ---------- */
  let dragging = false;
  function mount() {
    cv = q('brCanvas'); if (!cv) return;
    mounted = true; ctx = cv.getContext('2d');
    new ResizeObserver(() => { if (visible) resize(); }).observe(cv.parentElement);

    const pts = new Map(); let moved = 0, pinch = 0;
    const nearest = (x, y, maxD) => {
      let best = -1, bd = maxD * maxD;
      for (const n of nodes) {
        const dx = n.sx - x, dy = n.sy - y, d = dx * dx + dy * dy;
        if (d < bd && n.d > -0.6) { bd = d; best = n.r; }
      }
      return best;
    };
    const local = e => { const r = cv.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; };

    cv.addEventListener('pointerdown', e => {
      cv.setPointerCapture(e.pointerId); pts.set(e.pointerId, [e.clientX, e.clientY]);
      moved = 0; dragging = true; tween = null; vel = 0;
      if (pts.size === 2) { const [a, b] = [...pts.values()]; pinch = Math.hypot(a[0] - b[0], a[1] - b[1]); }
    });
    cv.addEventListener('pointermove', e => {
      const prev = pts.get(e.pointerId);
      if (!prev) { const [x, y] = local(e); hover = nearest(x, y, 16); cv.style.cursor = hover >= 0 ? 'pointer' : 'grab'; return; }
      const dx = e.clientX - prev[0], dy = e.clientY - prev[1];
      pts.set(e.pointerId, [e.clientX, e.clientY]);
      moved += Math.abs(dx) + Math.abs(dy);
      if (pts.size === 1) { yaw += dx * 0.0065; vel = dx * 0.0065; pitch = Math.max(-1.1, Math.min(1.1, pitch + dy * 0.0045)); }
      else if (pts.size === 2) {
        const [a, b] = [...pts.values()], d = Math.hypot(a[0] - b[0], a[1] - b[1]);
        if (pinch) zoom = Math.max(0.6, Math.min(2.4, zoom * d / pinch)); pinch = d;
      }
    });
    const end = e => {
      if (!pts.has(e.pointerId)) return;
      pts.delete(e.pointerId); if (!pts.size) dragging = false;
      if (moved < 5 && e.type === 'pointerup') { const [x, y] = local(e); const r = nearest(x, y, 22); if (r >= 0) select(r); else if (selected >= 0) select(selected); }
    };
    cv.addEventListener('pointerup', end); cv.addEventListener('pointercancel', end);
    cv.addEventListener('pointerleave', () => { hover = -1; });
    cv.addEventListener('wheel', e => { e.preventDefault(); zoom = Math.max(0.6, Math.min(2.4, zoom * Math.exp(-e.deltaY * 0.0012))); }, { passive: false });

    q('brRegions')?.addEventListener('click', e => { const b = e.target.closest('.br-reg'); if (b) select(+b.dataset.i); });
    q('brDetail')?.addEventListener('click', e => { const b = e.target.closest('[data-try]'); if (b && Brain.onTry) Brain.onTry(b.dataset.try); });

    const tog = (id, fn) => q(id)?.addEventListener('click', ev => { const on = fn(); ev.currentTarget.setAttribute('aria-pressed', String(on)); });
    tog('brRotate', () => (autoRotate = !autoRotate));
    tog('brSyn', () => (showSyn = !showSyn));
    tog('brLabels', () => (showLabels = !showLabels));
    q('brRotate')?.setAttribute('aria-pressed', String(autoRotate));
    q('brReset')?.addEventListener('click', () => { selected = -1; zoom = 1; tween = { yaw: yaw, pitch: 0.2 }; vel = 0; renderRegions(); renderDetail(); });
  }

  build();
  return { REGIONS, emit, setMode, setVital, bump, setVisible, refreshColors, select, onTry: null };
})();
